// 语音口 9600 8N1。现场模块按帧2编译：AA 55 cmd 55 AA，解析用这一帧（tag V）。
// 5A cmd 00 00 checksum 仍能认出（tag S），模块不发这种。
// 对不上的字节 -> tag R
module voice_parse #(
	parameter CLKS_PER_BIT = 15500
)(
	input			clk,
	input			rst_n,
	input			rx,
	output reg		got,
	output reg [7:0] code,
	output reg [7:0] tag
);
	wire [7:0] byte_d;
	wire byte_v;
	uart_rx #(.CLKS_PER_BIT(CLKS_PER_BIT), .STRICT_STOP(0)) u_rx (
		.clk(clk), .rst_n(rst_n), .rx(rx), .data(byte_d), .valid(byte_v)
	);

	reg [3:0] st;
	reg [7:0] cmd;
	reg [7:0] hold;
	reg use_hold;
	reg [19:0] gap;
	localparam S0 = 4'd0, S1 = 4'd1, S2 = 4'd2, S3 = 4'd3, S4 = 4'd4;
	localparam T0 = 4'd5, T1 = 4'd6, T2 = 4'd7, T3 = 4'd8;

	function [7:0] sum4;
		input [7:0] a, b, c, d;
		begin
			sum4 = a + b + c + d;
		end
	endfunction

	always @(posedge clk) begin
		if (!rst_n) begin
			st <= S0;
			cmd <= 8'd0;
			hold <= 8'd0;
			use_hold <= 1'b0;
			gap <= 20'd0;
			got <= 1'b0;
			code <= 8'd0;
			tag <= 8'd0;
		end else begin
			got <= 1'b0;
			if (byte_v || use_hold)
				gap <= 20'd0;
			else if ((st != S0) && (gap != 20'd750000))
				gap <= gap + 20'd1;
			if ((st != S0) && (gap == 20'd750000) && !byte_v && !use_hold) begin
				st <= S0;
				use_hold <= 1'b0;
				gap <= 20'd0;
				code <= 8'h00;
				tag <= "M";
				got <= 1'b1;
			end else if (byte_v || use_hold) begin
				if (use_hold)
					use_hold <= 1'b0;
				else
					hold <= byte_d;
				case (st)
					S0: begin
						if ((use_hold ? hold : byte_d) == 8'hAA)
							st <= S1;
						else if ((use_hold ? hold : byte_d) == 8'h5A)
							st <= T0;
						else begin
							code <= use_hold ? hold : byte_d;
							tag <= "R";
							got <= 1'b1;
						end
					end
					S1: begin
						if ((use_hold ? hold : byte_d) == 8'h55)
							st <= S2;
						else begin
							st <= S0;
							use_hold <= 1'b1;
						end
					end
					S2: begin
						cmd <= use_hold ? hold : byte_d;
						st <= S3;
					end
					S3: begin
						if ((use_hold ? hold : byte_d) == 8'h55)
							st <= S4;
						else begin
							st <= S0;
							use_hold <= 1'b1;
						end
					end
					S4: begin
						st <= S0;
						if ((use_hold ? hold : byte_d) == 8'hAA) begin
							code <= cmd;
							tag <= "V";
							got <= 1'b1;
						end else
							use_hold <= 1'b1;
					end
					T0: begin
						cmd <= use_hold ? hold : byte_d;
						st <= T1;
					end
					T1: begin
						if ((use_hold ? hold : byte_d) == 8'h00)
							st <= T2;
						else begin
							st <= S0;
							use_hold <= 1'b1;
						end
					end
					T2: begin
						if ((use_hold ? hold : byte_d) == 8'h00)
							st <= T3;
						else begin
							st <= S0;
							use_hold <= 1'b1;
						end
					end
					default: begin
						st <= S0;
						if ((use_hold ? hold : byte_d) == sum4(8'h5A, cmd, 8'h00, 8'h00)) begin
							code <= cmd;
							tag <= "S";
							got <= 1'b1;
						end else
							use_hold <= 1'b1;
					end
				endcase
			end
		end
	end
endmodule
