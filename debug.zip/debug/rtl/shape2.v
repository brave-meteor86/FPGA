// 采过形状阈值之后，按物体色相认左右两个团。白纸只看通道是不是接近，不看绝对亮度。
// 最多三团，从左到右分开记。每团只看自己外接框外圈四分之一的四个角。
// 角上像素超过外接框的八分之一算方形，否则算圆形。旁边有没有别的形状不影响。
module shape2 #(
	parameter ROI_X0 = 480,
	parameter ROI_Y0 = 300,
	parameter ROI_X1 = 1440,
	parameter ROI_Y1 = 780,
	parameter MIN_AREA = 80,
	parameter SEP = 40,
	parameter GAIN_R = 9'd310,
	parameter GAIN_G = 9'd256,
	parameter GAIN_B = 9'd490
)(
	input			clk,
	input			rst_n,
	input			vs,
	input			de,
	input signed [11:0] y_off,
	input [7:0]		r,
	input [7:0]		g,
	input [7:0]		b,
	input			got,
	input [7:0]		oref,
	input [7:0]		ogref,
	input [7:0]		obref,
	output reg		ready,
	output reg		v0,
	output reg		v1,
	output reg		v2,
	output reg		sq0,
	output reg		sq1,
	output reg		sq2,
	output reg [15:0] cx0,
	output reg [15:0] cy0,
	output reg [15:0] cx1,
	output reg [15:0] cy1,
	output reg [15:0] cx2,
	output reg [15:0] cy2,
	output [11:0] x0a,
	output [11:0] x0b,
	output [11:0] y0a,
	output [11:0] y0b,
	output [11:0] x1a,
	output [11:0] x1b,
	output [11:0] y1a,
	output [11:0] y1b,
	output [11:0] x2a,
	output [11:0] x2b,
	output [11:0] y2a,
	output [11:0] y2b
);
	function [7:0] bal;
		input [7:0] pix;
		input [8:0] gain;
		reg [16:0] m;
		begin
			m = pix * gain;
			bal = (m[16:8] > 9'd255) ? 8'd255 : m[15:8];
		end
	endfunction

	wire [7:0] br_w = bal(r, GAIN_R);
	wire [7:0] bg_w = bal(g, GAIN_G);
	wire [7:0] bb_w = bal(b, GAIN_B);
	reg [7:0] br, bg, bb;
	reg de_h;
	reg in_roi_h;
	reg [11:0] x_h, y_h;
	wire [7:0] hi = (br >= bg && br >= bb) ? br : ((bg >= bb) ? bg : bb);
	wire [7:0] lo = (br <= bg && br <= bb) ? br : ((bg <= bb) ? bg : bb);
	wire [8:0] span = {1'b0, hi} - lo;
	// 极差大于峰值的三分之一才算有颜色。白纸变亮变暗，极差仍远小于峰值。
	wire colorful = (span * 9'd3) > {1'b0, hi};
	wire [15:0] rg_a = br * ogref;
	wire [15:0] rg_b = bg * oref;
	wire [15:0] rb_a = br * obref;
	wire [15:0] rb_b = bb * oref;
	wire [15:0] gb_a = bg * obref;
	wire [15:0] gb_b = bb * ogref;
	wire [15:0] rg_d = (rg_a >= rg_b) ? (rg_a - rg_b) : (rg_b - rg_a);
	wire [15:0] rb_d = (rb_a >= rb_b) ? (rb_a - rb_b) : (rb_b - rb_a);
	wire [15:0] gb_d = (gb_a >= gb_b) ? (gb_a - gb_b) : (gb_b - gb_a);
	// 各通道比例跟样本相差不超过一半。
	wire like = ((rg_d << 1) <= (rg_a + rg_b)) && ((rb_d << 1) <= (rb_a + rb_b)) && ((gb_d << 1) <= (gb_a + gb_b));
	wire hit = got && colorful && like && (hi > 8'd16);

	reg vs_d, de_d;
	reg [11:0] x, y;
	wire signed [12:0] roi_sy0 = $signed({1'b0, ROI_Y0[11:0]}) + y_off;
	wire signed [12:0] roi_sy1 = $signed({1'b0, ROI_Y1[11:0]}) + y_off;
	wire in_roi = (x >= ROI_X0) && (x < ROI_X1) && (y >= roi_sy0[11:0]) && (y < roi_sy1[11:0]);

	reg [19:0] a0, a1, a2;
	reg [31:0] sx0, sy0, sx1, sy1, sx2, sy2;
	reg [11:0] n0, m0, ny0, my0;
	reg [11:0] n1, m1, ny1, my1;
	reg [11:0] n2, m2, ny2, my2;

	wire [12:0] xw = {1'b0, x_h};
	wire [12:0] yw = {1'b0, y_h};
	wire near0 = (a0 != 20'd0) &&
		(xw + SEP >= {1'b0, n0}) && (xw <= {1'b0, m0} + SEP) &&
		(yw + SEP >= {1'b0, ny0}) && (yw <= {1'b0, my0} + SEP);
	wire near1 = (a1 != 20'd0) &&
		(xw + SEP >= {1'b0, n1}) && (xw <= {1'b0, m1} + SEP) &&
		(yw + SEP >= {1'b0, ny1}) && (yw <= {1'b0, my1} + SEP);

	reg [19:0] la0, la1, la2;
	reg [31:0] lsx0, lsy0, lsx1, lsy1, lsx2, lsy2;
	reg [11:0] ln0, lm0, lny0, lmy0, ln1, lm1, lny1, lmy1, ln2, lm2, lny2, lmy2;
	reg [17:0] kc0, kc1, kc2, lkc0, lkc1, lkc2;
	assign x0a = ln0;
	assign x0b = lm0;
	assign y0a = lny0;
	assign y0b = lmy0;
	assign x1a = ln1;
	assign x1b = lm1;
	assign y1a = lny1;
	assign y1b = lmy1;
	assign x2a = ln2;
	assign x2b = lm2;
	assign y2a = lny2;
	assign y2b = lmy2;
	reg latched;

	function aspect_ok;
		input [11:0] nxx, mxx, nyy, myy;
		reg [12:0] bw, bh, dlt, side;
		begin
			bw = {1'b0, mxx} - {1'b0, nxx} + 13'd1;
			bh = {1'b0, myy} - {1'b0, nyy} + 13'd1;
			dlt = (bw >= bh) ? (bw - bh) : (bh - bw);
			side = (bw >= bh) ? bw : bh;
			aspect_ok = (mxx >= nxx) && (myy >= nyy) && (side > 13'd8) && ((dlt << 3) < side);
		end
	endfunction

	function in_corner;
		input [11:0] px, py, x0, x1, y0, y1;
		reg [11:0] qw, qh;
		begin
			qw = (x1 - x0) >> 2;
			qh = (y1 - y0) >> 2;
			in_corner = (x1 > x0 + 12'd16) && (y1 > y0 + 12'd16) &&
				(px >= x0) && (px <= x1) && (py >= y0) && (py <= y1) &&
				((px < x0 + qw) || (px > x1 - qw)) &&
				((py < y0 + qh) || (py > y1 - qh));
		end
	endfunction

	wire a0ok = (la0 >= MIN_AREA) && aspect_ok(ln0, lm0, lny0, lmy0);
	wire a1ok = (la1 >= MIN_AREA) && aspect_ok(ln1, lm1, lny1, lmy1);
	wire a2ok = (la2 >= MIN_AREA) && aspect_ok(ln2, lm2, lny2, lmy2);
	wire [12:0] bw0 = {1'b0, lm0} - {1'b0, ln0} + 13'd1;
	wire [12:0] bh0 = {1'b0, lmy0} - {1'b0, lny0} + 13'd1;
	wire [12:0] bw1 = {1'b0, lm1} - {1'b0, ln1} + 13'd1;
	wire [12:0] bh1 = {1'b0, lmy1} - {1'b0, lny1} + 13'd1;
	wire [12:0] bw2 = {1'b0, lm2} - {1'b0, ln2} + 13'd1;
	wire [12:0] bh2 = {1'b0, lmy2} - {1'b0, lny2} + 13'd1;
	wire [23:0] box0 = bw0 * bh0;
	wire [23:0] box1 = bw1 * bh1;
	wire [23:0] box2 = bw2 * bh2;
	wire sq_geom0 = a0ok && ({6'd0, lkc0} > (box0 >> 3));
	wire sq_geom1 = a1ok && ({6'd0, lkc1} > (box1 >> 3));
	wire sq_geom2 = a2ok && ({6'd0, lkc2} > (box2 >> 3));

	reg [2:0] st;
	reg div_start;
	reg [31:0] div_n;
	reg [19:0] div_d;
	wire [15:0] quot;
	wire div_done;

	div_u32 u_div (
		.clk(clk), .rst_n(rst_n), .start(div_start),
		.dividend(div_n), .divisor(div_d), .quotient(quot), .done(div_done)
	);

	always @(posedge clk) begin
		if (!rst_n) begin
			vs_d <= 1'b0;
			de_d <= 1'b0;
			x <= 12'd0;
			y <= 12'd0;
			br <= 8'd0;
			bg <= 8'd0;
			bb <= 8'd0;
			de_h <= 1'b0;
			in_roi_h <= 1'b0;
			x_h <= 12'd0;
			y_h <= 12'd0;
			a0 <= 20'd0; a1 <= 20'd0; a2 <= 20'd0;
			sx0 <= 32'd0; sy0 <= 32'd0; sx1 <= 32'd0; sy1 <= 32'd0; sx2 <= 32'd0; sy2 <= 32'd0;
			n0 <= 12'hFFF; m0 <= 12'd0; ny0 <= 12'hFFF; my0 <= 12'd0;
			n1 <= 12'hFFF; m1 <= 12'd0; ny1 <= 12'hFFF; my1 <= 12'd0;
			n2 <= 12'hFFF; m2 <= 12'd0; ny2 <= 12'hFFF; my2 <= 12'd0;
			la0 <= 20'd0; la1 <= 20'd0; la2 <= 20'd0;
			lsx0 <= 32'd0; lsy0 <= 32'd0; lsx1 <= 32'd0; lsy1 <= 32'd0; lsx2 <= 32'd0; lsy2 <= 32'd0;
			ln0 <= 12'd0; lm0 <= 12'd0; lny0 <= 12'd0; lmy0 <= 12'd0;
			ln1 <= 12'd0; lm1 <= 12'd0; lny1 <= 12'd0; lmy1 <= 12'd0;
			ln2 <= 12'd0; lm2 <= 12'd0; lny2 <= 12'd0; lmy2 <= 12'd0;
			kc0 <= 18'd0; kc1 <= 18'd0; kc2 <= 18'd0; lkc0 <= 18'd0; lkc1 <= 18'd0; lkc2 <= 18'd0;
			latched <= 1'b0;
			st <= 3'd0;
			div_start <= 1'b0;
			div_n <= 32'd0;
			div_d <= 20'd0;
			ready <= 1'b0;
			v0 <= 1'b0; v1 <= 1'b0; v2 <= 1'b0;
			sq0 <= 1'b0; sq1 <= 1'b0; sq2 <= 1'b0;
			cx0 <= 16'd0; cy0 <= 16'd0; cx1 <= 16'd0; cy1 <= 16'd0; cx2 <= 16'd0; cy2 <= 16'd0;
		end else begin
			vs_d <= vs;
			de_d <= de;
			br <= br_w;
			bg <= bg_w;
			bb <= bb_w;
			de_h <= de;
			in_roi_h <= in_roi;
			x_h <= x;
			y_h <= y;
			div_start <= 1'b0;
			ready <= 1'b0;
			latched <= 1'b0;
			if (vs_d && !vs) begin
				la0 <= a0; la1 <= a1; la2 <= a2;
				lsx0 <= sx0; lsy0 <= sy0; lsx1 <= sx1; lsy1 <= sy1; lsx2 <= sx2; lsy2 <= sy2;
				ln0 <= n0; lm0 <= m0; lny0 <= ny0; lmy0 <= my0;
				ln1 <= n1; lm1 <= m1; lny1 <= ny1; lmy1 <= my1;
				ln2 <= n2; lm2 <= m2; lny2 <= ny2; lmy2 <= my2;
				lkc0 <= kc0; lkc1 <= kc1; lkc2 <= kc2;
				kc0 <= 18'd0; kc1 <= 18'd0; kc2 <= 18'd0;
				latched <= 1'b1;
				a0 <= 20'd0; a1 <= 20'd0; a2 <= 20'd0;
				sx0 <= 32'd0; sy0 <= 32'd0; sx1 <= 32'd0; sy1 <= 32'd0; sx2 <= 32'd0; sy2 <= 32'd0;
				n0 <= 12'hFFF; m0 <= 12'd0; ny0 <= 12'hFFF; my0 <= 12'd0;
				n1 <= 12'hFFF; m1 <= 12'd0; ny1 <= 12'hFFF; my1 <= 12'd0;
				n2 <= 12'hFFF; m2 <= 12'd0; ny2 <= 12'hFFF; my2 <= 12'd0;
				x <= 12'd0;
				y <= 12'd0;
			end else begin
				if (de_h && in_roi_h && hit) begin
					if ((a0 == 20'd0) || near0) begin
						if (a0 == 20'd0) begin
							n0 <= x_h; m0 <= x_h; ny0 <= y_h; my0 <= y_h;
						end else begin
							if (x_h < n0) n0 <= x_h;
							if (x_h > m0) m0 <= x_h;
							if (y_h < ny0) ny0 <= y_h;
							if (y_h > my0) my0 <= y_h;
						end
						a0 <= a0 + 20'd1;
						sx0 <= sx0 + x_h;
						sy0 <= sy0 + y_h;
						if (in_corner(x_h, y_h, ln0, lm0, lny0, lmy0))
							kc0 <= kc0 + 18'd1;
					end else if ((a1 == 20'd0) || near1) begin
						if (a1 == 20'd0) begin
							n1 <= x_h; m1 <= x_h; ny1 <= y_h; my1 <= y_h;
						end else begin
							if (x_h < n1) n1 <= x_h;
							if (x_h > m1) m1 <= x_h;
							if (y_h < ny1) ny1 <= y_h;
							if (y_h > my1) my1 <= y_h;
						end
						a1 <= a1 + 20'd1;
						sx1 <= sx1 + x_h;
						sy1 <= sy1 + y_h;
						if (in_corner(x_h, y_h, ln1, lm1, lny1, lmy1))
							kc1 <= kc1 + 18'd1;
					end else begin
						if (a2 == 20'd0) begin
							n2 <= x_h; m2 <= x_h; ny2 <= y_h; my2 <= y_h;
						end else begin
							if (x_h < n2) n2 <= x_h;
							if (x_h > m2) m2 <= x_h;
							if (y_h < ny2) ny2 <= y_h;
							if (y_h > my2) my2 <= y_h;
						end
						a2 <= a2 + 20'd1;
						sx2 <= sx2 + x_h;
						sy2 <= sy2 + y_h;
						if (in_corner(x_h, y_h, ln2, lm2, lny2, lmy2))
							kc2 <= kc2 + 18'd1;
					end
				end
				if (de)
					x <= x + 12'd1;
				else if (de_d) begin
					x <= 12'd0;
					y <= y + 12'd1;
				end
			end

			case (st)
				3'd0: begin
					if (latched) begin
						v0 <= a0ok;
						v1 <= a1ok;
						v2 <= a2ok;
						sq0 <= sq_geom0;
						sq1 <= sq_geom1;
						sq2 <= sq_geom2;
						cx0 <= 16'd0; cy0 <= 16'd0; cx1 <= 16'd0; cy1 <= 16'd0; cx2 <= 16'd0; cy2 <= 16'd0;
						if (la0 >= MIN_AREA) begin
							div_n <= lsx0;
							div_d <= la0;
							div_start <= 1'b1;
							st <= 3'd1;
						end else if (la1 >= MIN_AREA) begin
							div_n <= lsx1;
							div_d <= la1;
							div_start <= 1'b1;
							st <= 3'd3;
						end else if (la2 >= MIN_AREA) begin
							div_n <= lsx2;
							div_d <= la2;
							div_start <= 1'b1;
							st <= 3'd5;
						end else
							ready <= 1'b1;
					end
				end
				3'd1: if (div_done) begin
					cx0 <= quot;
					div_n <= lsy0;
					div_d <= la0;
					div_start <= 1'b1;
					st <= 3'd2;
				end
				3'd2: if (div_done) begin
					cy0 <= quot;
					if (la1 >= MIN_AREA) begin
						div_n <= lsx1;
						div_d <= la1;
						div_start <= 1'b1;
						st <= 3'd3;
					end else if (la2 >= MIN_AREA) begin
						div_n <= lsx2;
						div_d <= la2;
						div_start <= 1'b1;
						st <= 3'd5;
					end else begin
						ready <= 1'b1;
						st <= 3'd0;
					end
				end
				3'd3: if (div_done) begin
					cx1 <= quot;
					div_n <= lsy1;
					div_d <= la1;
					div_start <= 1'b1;
					st <= 3'd4;
				end
				3'd4: if (div_done) begin
					cy1 <= quot;
					if (la2 >= MIN_AREA) begin
						div_n <= lsx2;
						div_d <= la2;
						div_start <= 1'b1;
						st <= 3'd5;
					end else begin
						ready <= 1'b1;
						st <= 3'd0;
					end
				end
				3'd5: if (div_done) begin
					cx2 <= quot;
					div_n <= lsy2;
					div_d <= la2;
					div_start <= 1'b1;
					st <= 3'd6;
				end
				3'd6: if (div_done) begin
					cy2 <= quot;
					ready <= 1'b1;
					st <= 3'd0;
				end
				default: begin
					ready <= 1'b1;
					st <= 3'd0;
				end
			endcase
		end
	end
endmodule
