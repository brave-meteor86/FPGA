// 手势只出结果，不发机械臂。窗口左/右/上/下，中间大块算张开，小块算握拳。
module gest_rep #(
	parameter ROI_X0 = 480,
	parameter ROI_Y0 = 300,
	parameter ROI_X1 = 1440,
	parameter ROI_Y1 = 780,
	parameter MIN_AREA = 80,
	parameter PALM_AREA = 8000,
	parameter GAIN_R = 9'd310,
	parameter GAIN_G = 9'd256,
	parameter GAIN_B = 9'd490
)(
	input			clk,
	input			rst_n,
	input			vs,
	input			de,
	input signed [11:0] y_off,
	input [7:0]		r,
	input [7:0]		g,
	input [7:0]		b,
	output reg		ready,
	output reg [7:0] kind,
	output reg [15:0] cx,
	output reg [15:0] cy,
	output reg [19:0] area,
	output reg		box_ok,
	output reg [11:0] bx0,
	output reg [11:0] bx1,
	output reg [11:0] by0,
	output reg [11:0] by1,
	input			cap_arm,
	output reg		cal_done,
	output reg [7:0] cal_r,
	output reg [7:0] cal_g,
	output reg [7:0] cal_b
);
	function [7:0] bal;
		input [7:0] pix;
		input [8:0] gain;
		reg [16:0] m;
		begin
			m = pix * gain;
			bal = (m[16:8] > 9'd255) ? 8'd255 : m[15:8];
		end
	endfunction

	wire [7:0] br = bal(r, GAIN_R);
	wire [7:0] bg = bal(g, GAIN_G);
	wire [7:0] bb = bal(b, GAIN_B);
	wire frame_done;
	wire [19:0] area_h;
	wire [31:0] sumx_h, sumy_h;
	wire [19:0] area_r, area_g, area_b, area_o;
	wire [31:0] sumx_r, sumy_r, sumx_g, sumy_g, sumx_b, sumy_b, sumx_o, sumy_o;
	wire [11:0] px, py;
	wire [11:0] minx_r, maxx_r, miny_r, maxy_r;
	wire [11:0] minx_g, maxx_g, miny_g, maxy_g;
	wire [11:0] minx_b, maxx_b, miny_b, maxy_b;
	wire [11:0] minx_o, maxx_o, miny_o, maxy_o;
	wire [11:0] minx_h, maxx_h, miny_h, maxy_h;

	vision_stat #(
		.ROI_X0(ROI_X0), .ROI_Y0(ROI_Y0), .ROI_X1(ROI_X1), .ROI_Y1(ROI_Y1)
	) u_stat (
		.clk(clk), .rst_n(rst_n), .vs(vs), .de(de), .y_off(y_off), .r(br), .g(bg), .b(bb),
		.thr_r(8'd70), .thr_g(8'd24), .thr_b(8'd24), .stab(8'd16),
		.auto_on(1'b0),
		.rr(8'd0), .rg(8'd0), .rb(8'd0),
		.gr(8'd0), .gg(8'd0), .gb(8'd0),
		.br(8'd0), .bg(8'd0), .bb(8'd0),
		.kr(8'd0), .kg(8'd0), .kb(8'd0),
		.hand_mode(cal_ok ? 2'd2 : 2'd1),
		.href_r(href_r), .href_g(href_g), .href_b(href_b), .hand_tol(8'd72),
		.frame_done(frame_done), .x(px), .y(py),
		.area_r(area_r), .area_g(area_g), .area_b(area_b), .area_o(area_o), .area_h(area_h),
		.sumx_r(sumx_r), .sumy_r(sumy_r), .sumx_g(sumx_g), .sumy_g(sumy_g),
		.sumx_b(sumx_b), .sumy_b(sumy_b), .sumx_o(sumx_o), .sumy_o(sumy_o),
		.sumx_h(sumx_h), .sumy_h(sumy_h),
		.minx_r(minx_r), .maxx_r(maxx_r), .miny_r(miny_r), .maxy_r(maxy_r),
		.minx_g(minx_g), .maxx_g(maxx_g), .miny_g(miny_g), .maxy_g(maxy_g),
		.minx_b(minx_b), .maxx_b(maxx_b), .miny_b(miny_b), .maxy_b(maxy_b),
		.minx_o(minx_o), .maxx_o(maxx_o), .miny_o(miny_o), .maxy_o(maxy_o),
		.minx_h(minx_h), .maxx_h(maxx_h), .miny_h(miny_h), .maxy_h(maxy_h)
	);

	localparam ROI_W = ROI_X1 - ROI_X0;
	localparam ROI_H = ROI_Y1 - ROI_Y0;
	localparam X_L = ROI_X0 + ROI_W / 3;
	localparam X_R = ROI_X0 + (ROI_W * 2) / 3;
	wire signed [12:0] gy0 = $signed({1'b0, ROI_Y0[11:0]}) + y_off;
	wire [15:0] Y_U = {4'd0, gy0[11:0]} + ROI_H / 3;
	wire [15:0] Y_D = {4'd0, gy0[11:0]} + (ROI_H * 2) / 3;

	reg [1:0] st;
	reg [31:0] div_n;
	reg [19:0] div_d;
	reg div_start;
	wire [15:0] quot;
	wire div_done;
	reg [19:0] use_a;
	reg [31:0] use_sy;
	reg			cal_ok;
	reg [7:0]	href_r, href_g, href_b;
	reg			cap_req, cap_run;
	reg [23:0]	sr, sg, sb;
	reg [15:0]	sc;
	reg [1:0]	cst;
	reg			div2_start;
	reg [31:0]	div2_n;
	reg [19:0]	div2_d;
	wire [15:0]	quot2;
	wire		div2_done;
	localparam HSX0 = 12'd920;
	localparam HSX1 = 12'd1000;
	wire [11:0] hsy0 = gy0[11:0] + 12'd260;
	wire [11:0] hsy1 = gy0[11:0] + 12'd340;
	wire in_sw = de && (px >= HSX0) && (px < HSX1) && (py >= hsy0) && (py < hsy1);

	div_u32 u_div (
		.clk(clk), .rst_n(rst_n), .start(div_start),
		.dividend(div_n), .divisor(div_d), .quotient(quot), .done(div_done)
	);
	div_u32 u_div2 (
		.clk(clk), .rst_n(rst_n), .start(div2_start),
		.dividend(div2_n), .divisor(div2_d), .quotient(quot2), .done(div2_done)
	);

	always @(posedge clk) begin
		if (!rst_n) begin
			st <= 2'd0;
			div_n <= 32'd0;
			div_d <= 20'd0;
			div_start <= 1'b0;
			use_a <= 20'd0;
			use_sy <= 32'd0;
			ready <= 1'b0;
			kind <= "N";
			cx <= 16'd0;
			cy <= 16'd0;
			area <= 20'd0;
			box_ok <= 1'b0;
			bx0 <= 12'd0;
			bx1 <= 12'd0;
			by0 <= 12'd0;
			by1 <= 12'd0;
		end else begin
			div_start <= 1'b0;
			ready <= 1'b0;
			case (st)
				2'd0: begin
					if (frame_done) begin
						area <= area_h;
						use_a <= area_h;
						use_sy <= sumy_h;
						bx0 <= minx_h;
						bx1 <= maxx_h;
						by0 <= miny_h;
						by1 <= maxy_h;
						if (area_h >= MIN_AREA) begin
							box_ok <= 1'b1;
							div_n <= sumx_h;
							div_d <= area_h;
							div_start <= 1'b1;
							st <= 2'd1;
						end else begin
							box_ok <= 1'b0;
							kind <= "N";
							cx <= 16'd0;
							cy <= 16'd0;
							ready <= 1'b1;
						end
					end
				end
				2'd1: begin
					if (div_done) begin
						cx <= quot;
						div_n <= use_sy;
						div_d <= use_a;
						div_start <= 1'b1;
						st <= 2'd2;
					end
				end
				default: begin
					if (div_done) begin
						cy <= quot;
						if (quot < Y_U && cx >= X_L && cx <= X_R)
							kind <= "U";
						else if (quot > Y_D && cx >= X_L && cx <= X_R)
							kind <= "D";
						else if (cx < X_L)
							kind <= "L";
						else if (cx > X_R)
							kind <= "R";
						else if (use_a >= PALM_AREA)
							kind <= "O";
						else
							kind <= "F";
						ready <= 1'b1;
						st <= 2'd0;
					end
				end
			endcase
		end
	end

	// 上电用手心 R142 G107 B96。再点手心标定会换成新的颜色。
	always @(posedge clk) begin
		if (!rst_n) begin
			cal_ok <= 1'b1;
			href_r <= 8'd142;
			href_g <= 8'd107;
			href_b <= 8'd96;
			cap_req <= 1'b0;
			cap_run <= 1'b0;
			sr <= 24'd0;
			sg <= 24'd0;
			sb <= 24'd0;
			sc <= 16'd0;
			cst <= 2'd0;
			div2_start <= 1'b0;
			div2_n <= 32'd0;
			div2_d <= 20'd0;
			cal_done <= 1'b0;
			cal_r <= 8'd0;
			cal_g <= 8'd0;
			cal_b <= 8'd0;
		end else begin
			div2_start <= 1'b0;
			cal_done <= 1'b0;
			if (cap_arm)
				cap_req <= 1'b1;
			if (in_sw && cap_run && !frame_done) begin
				sr <= sr + br;
				sg <= sg + bg;
				sb <= sb + bb;
				sc <= sc + 16'd1;
			end
			if (frame_done && cap_req) begin
				cap_req <= 1'b0;
				cap_run <= 1'b1;
				sr <= 24'd0;
				sg <= 24'd0;
				sb <= 24'd0;
				sc <= 16'd0;
			end else if (frame_done && cap_run) begin
				cap_run <= 1'b0;
				if ((sc >= 16'd1000) && (cst == 2'd0)) begin
					div2_n <= sr;
					div2_d <= sc;
					div2_start <= 1'b1;
					cst <= 2'd1;
				end else begin
					cal_ok <= 1'b0;
					cal_r <= 8'd0;
					cal_g <= 8'd0;
					cal_b <= 8'd0;
					cal_done <= 1'b1;
				end
			end
			if ((cst == 2'd1) && div2_done) begin
				href_r <= quot2[7:0];
				cal_r <= quot2[7:0];
				div2_n <= sg;
				div2_d <= sc;
				div2_start <= 1'b1;
				cst <= 2'd2;
			end else if ((cst == 2'd2) && div2_done) begin
				href_g <= quot2[7:0];
				cal_g <= quot2[7:0];
				div2_n <= sb;
				div2_d <= sc;
				div2_start <= 1'b1;
				cst <= 2'd3;
			end else if ((cst == 2'd3) && div2_done) begin
				href_b <= quot2[7:0];
				cal_b <= quot2[7:0];
				cal_ok <= 1'b1;
				cal_done <= 1'b1;
				cst <= 2'd0;
			end
		end
	end
endmodule
