// 六个调试段共用一条调试串口。上电在 D1。电脑发 ASCII 1..6 切换。
// D1 语音控制  D2 颜色分类  D3 形状分类  D4 手势跟随  D5 手柄控制  D6 调试
// 语音 01..05 分别进入 D1..D5。D5 松开 I2C，交给手柄。
// 按键只在 D6 发 I2C。切到模式就能直接操作。语音「开始」「停止」不动作。
// 只要换成另一个模式，就连发两笔回中再归位。现场从语音切走的第一笔不应，第二笔才动。进手柄模式要等这段做完再松开 I2C。
// 大约每秒上报 Dn Vxx P0/P1。D 是当前模式，P1 表示单片机刚应答过地址。
// 方向一步 1.0 cm。手势模式只识别，不发机械臂。形状每种结果只发一次。
// 颜色抓取用上一帧已经算完的中心。说中一次连发两笔 0x15，隔约 100 ms，避开单片机第一笔应答了却不动。
// 两笔都发出后，新的语音先读 8051：0x00 才收下，0x01 丢掉。满 10 秒仍不是空闲，也重新接收。
// 同一句的第二笔 0x15 照发。电脑调试串口切模式不受这道门限制。
module dbg_shell #(
	parameter ROI_X0 = 480,
	parameter ROI_Y0 = 300,
	parameter ROI_X1 = 1440,
	parameter ROI_Y1 = 780,
	parameter MIN_AREA = 80,
	parameter PALM_AREA = 8000,
	parameter SEP = 40,
	parameter DBG_CLKS = 1292, // 115200，clk_pixel_2x 6.7204 ns
	parameter VOICE_CLKS = 15500,
	parameter ARM_CLKS = 14880, // 148.8 MHz 下 SCL 高电平约 100 us
	parameter FW_VER = 8'h3D, // 调试串口横幅里的版本，形如 D1 V3D P1 A0
	parameter HOME_RETRY = 15000000, // 第一笔应答后再等约 100 ms，再发第二笔
	parameter HB_CLKS = 148800000,
	parameter CHAIN_WAIT = 32'd1339200000, // 9 秒：夹取 6.1 秒、回中约 2 秒、归位 0.8 秒，到点马上看视野
	parameter GRAB_LOCK = 32'd1488000000, // 10 秒：状态一直不来，也重新接收语音
	parameter GAIN_R = 9'd310,
	parameter GAIN_G = 9'd256,
	parameter GAIN_B = 9'd490
)(
	input			clk,
	input			rst_n,
	input			vs,
	input			de,
	input [7:0]		r,
	input [7:0]		g,
	input [7:0]		b,
	input [7:0]		paper_r,
	input [7:0]		paper_g,
	input [7:0]		paper_b,
	input			dbg_rx,
	input			voice_rx,
	input			arm_scl_i,
	input			arm_sda_i,
	output			arm_scl_oe,
	output			arm_sda_oe,
	output			arm_sda_rel,
	output			dbg_tx,
	output reg		auto_on,
	output reg [7:0] ref_rr,
	output reg [7:0] ref_rg,
	output reg [7:0] ref_rb,
	output reg [7:0] ref_gr,
	output reg [7:0] ref_gg,
	output reg [7:0] ref_gb,
	output reg [7:0] ref_br,
	output reg [7:0] ref_bg,
	output reg [7:0] ref_bb,
	output reg [7:0] ref_kr,
	output reg [7:0] ref_kg,
	output reg [7:0] ref_kb,
	output [2:0] stage_o,
	output		sh_got,
	output		sh_v0,
	output		sh_sq0,
	output		sh_v1,
	output		sh_sq1,
	output		sh_v2,
	output		sh_sq2,
	output [11:0] sh_x0a,
	output [11:0] sh_x0b,
	output [11:0] sh_y0a,
	output [11:0] sh_y0b,
	output [11:0] sh_x1a,
	output [11:0] sh_x1b,
	output [11:0] sh_y1a,
	output [11:0] sh_y1b,
	output [11:0] sh_x2a,
	output [11:0] sh_x2b,
	output [11:0] sh_y2a,
	output [11:0] sh_y2b,
	output		g_box,
	output [11:0] g_bx0,
	output [11:0] g_bx1,
	output [11:0] g_by0,
	output [11:0] g_by1,
	output reg		samp_on
);
	function [31:0] dec4;
		input [9:0] v;
		reg [9:0] t;
		reg [3:0] a, b, c, d;
		begin
			a = v / 10'd1000;
			t = v % 10'd1000;
			b = t / 10'd100;
			t = t % 10'd100;
			c = t / 10'd10;
			d = t % 10'd10;
			dec4 = {"0" + a, "0" + b, "0" + c, "0" + d};
		end
	endfunction

	function [23:0] dec3b;
		input [7:0] v;
		reg [7:0] t;
		reg [3:0] a, b, c;
		begin
			a = v / 8'd100;
			t = v % 8'd100;
			b = t / 8'd10;
			c = t % 8'd10;
			dec3b = {"0" + a, "0" + b, "0" + c};
		end
	endfunction

	function [8:0] clamp_gain;
		input [15:0] q;
		begin
			if (q == 16'd0)
				clamp_gain = 9'd1;
			else if (q > 16'd511)
				clamp_gain = 9'd511;
			else
				clamp_gain = q[8:0];
		end
	endfunction

	function [7:0] hexd;
		input [3:0] n;
		begin
			hexd = (n < 4'd10) ? ("0" + n) : ("A" + (n - 4'd10));
		end
	endfunction

	function [111:0] xyline;
		input [7:0] a;
		input [7:0] c;
		input [15:0] x;
		input [15:0] y;
		begin
			xyline = {a, c, " ", hexd(x[15:12]), hexd(x[11:8]), hexd(x[7:4]), hexd(x[3:0]), " ",
				hexd(y[15:12]), hexd(y[11:8]), hexd(y[7:4]), hexd(y[3:0]), 8'h0D, 8'h0A};
		end
	endfunction

	function signed [11:0] yclamp;
		input [15:0] raw;
		reg signed [15:0] s;
		begin
			s = raw;
			if (s > 16'sd300)
				yclamp = 12'sd300;
			else if (s < -16'sd300)
				yclamp = -12'sd300;
			else
				yclamp = s[11:0];
		end
	endfunction

	function voice_need;
		input [7:0] tag;
		input [7:0] code;
		begin
			voice_need = 1'b0;
			if (tag == "V")
				voice_need = ((code >= 8'h20) && (code <= 8'h27))
					|| ((code >= 8'h30) && (code <= 8'h32))
					|| (code == 8'h40) || (code == 8'h41) || (code == 8'h50)
					|| ((code >= 8'h60) && (code <= 8'h65));
		end
	endfunction

	function [31:0] d2;
		input [15:0] xa, ya, xb, yb;
		reg [15:0] dx, dy;
		begin
			dx = (xa > xb) ? (xa - xb) : (xb - xa);
			dy = (ya > yb) ? (ya - yb) : (yb - ya);
			d2 = dx * dx + dy * dy;
		end
	endfunction

	function [151:0] cline;
		input [7:0] c;
		input			ok;
		input [15:0] x;
		input [15:0] y;
		input [15:0] a;
		reg [15:0] xx, yy, aa;
		begin
			xx = ok ? x : 16'd0;
			yy = ok ? y : 16'd0;
			aa = ok ? a : 16'd0;
			cline = { "C", c, " ",
				hexd(xx[15:12]), hexd(xx[11:8]), hexd(xx[7:4]), hexd(xx[3:0]), " ",
				hexd(yy[15:12]), hexd(yy[11:8]), hexd(yy[7:4]), hexd(yy[3:0]), " ",
				hexd(aa[15:12]), hexd(aa[11:8]), hexd(aa[7:4]), hexd(aa[3:0]), 8'h0D, 8'h0A};
		end
	endfunction

	reg [2:0] stage;
	reg [1:0] ywait;
	reg [7:0] yhi;
	reg signed [11:0] y_off;
	reg [2:0] cwait;
	reg bwait;
	reg [7:0] thr_r, thr_g, thr_b, stab;
	reg [7:0] c_r, c_g, c_b;
	reg mwait;
	reg slot_lv, slot_mv, slot_rv;
	reg [15:0] slot_lx, slot_ly, slot_mx, slot_my, slot_rx, slot_ry;
	reg jpend;
	reg [7:0] jcol, jslot;
	reg chain_on, chain_sq;
	reg [31:0] chain_dly;
	reg grab_on, grab_shot;
	reg [7:0] grab_p0, grab_p1;
	reg [29:0] grab_dly;
	reg grab_hold;
	reg tmo_run;
	reg [31:0] grab_tmo;
	reg voice_keep, voice_replay, stat_pulse, stat_busy, stat_toss;
	reg [7:0] keep_code, keep_tag;

	wire [7:0] dbg_byte;
	wire dbg_v;
	uart_rx #(.CLKS_PER_BIT(DBG_CLKS)) u_dbg (
		.clk(clk), .rst_n(rst_n), .rx(dbg_rx), .data(dbg_byte), .valid(dbg_v)
	);

	wire voice_got;
	wire [7:0] voice_code, voice_tag;
	voice_parse #(.CLKS_PER_BIT(VOICE_CLKS)) u_voice (
		.clk(clk), .rst_n(rst_n), .rx(voice_rx),
		.got(voice_got), .code(voice_code), .tag(voice_tag)
	);
	wire voice_use = voice_replay || (voice_got && !grab_hold);
	wire [7:0] vcode_now = voice_replay ? keep_code : voice_code;
	wire [7:0] vtag_now = voice_replay ? keep_tag : voice_tag;

	wire key_motion = (dbg_byte == "U") || (dbg_byte == "D") || (dbg_byte == "L") || (dbg_byte == "R")
		|| (dbg_byte == "O") || (dbg_byte == "C") || (dbg_byte == "W") || (dbg_byte == "X")
		|| (dbg_byte == "Y") || (dbg_byte == "E") || (dbg_byte == "T") || (dbg_byte == "V")
		|| (dbg_byte == "H") || (dbg_byte == "G") || (dbg_byte == "Z") || (dbg_byte == "S");
	wire man_req, man_echo_v, man_echo_stop, man_echo_hex;
	wire [7:0] man_cmd, man_p0, man_p1, man_p2, man_c0, man_c1, man_grp;
	arm_man u_man (
		.clk(clk), .rst_n(rst_n),
		.key_v(dbg_v && (ywait == 2'd0) && (cwait == 3'd0) && !bwait && key_motion && (stage == 3'd6)),
		.key(dbg_byte),
		.voice_v(voice_use && !bus_off && !home_need && !home_pulse && (stage == 3'd1)
			&& !((vtag_now == "V") && (
				((vcode_now >= 8'h30) && (vcode_now <= 8'h32))
				|| (vcode_now == 8'h10) || (vcode_now == 8'h11)))
			&& !((vtag_now == "S") && ((vcode_now == 8'h07) || (vcode_now == 8'h08)))),
		.voice_tag(vtag_now), .voice_code(vcode_now),
		.req(man_req), .cmd(man_cmd), .p0(man_p0), .p1(man_p1), .p2(man_p2),
		.echo_v(man_echo_v), .echo_stop(man_echo_stop), .echo_hex(man_echo_hex),
		.echo_c0(man_c0), .echo_c1(man_c1), .echo_grp(man_grp)
	);

	reg			armed, bus_off;
	reg			home_pulse, home_to5, home_need, home_wait, home_busy, home_second;
	reg [1:0]	home_gap;
	reg [29:0]	off_dly, home_dly;
	reg			auto_req, auto_echo, auto_hex, auto_stop;
	reg [7:0]	auto_cmd, auto_p0, auto_p1, auto_p2, auto_c0, auto_c1, auto_grp;
	reg [7:0]	hold_kind, last_shape;
	reg [4:0]	cool;
	reg			gpend, hpend, cap_pulse;
	reg [1:0]	gphase;
	reg [7:0]	gk, hr, hg, hb, gseen, gsent;
	reg [3:0]	gcnt;
	reg [15:0]	gx, gy;
	reg [19:0]	ga;
	// 回中还没发完时，点动不能再上车。否则线上会变成先 0x16 再 0x14，单片机用点动把归位清掉。
	wire home_hold = home_need | home_pulse;
	wire use_man = man_req & ~home_hold;
	wire [7:0] arm_cmd = use_man ? man_cmd : auto_cmd;
	wire [7:0] arm_p0 = use_man ? man_p0 : auto_p0;
	wire [7:0] arm_p1 = use_man ? man_p1 : auto_p1;
	wire [7:0] arm_p2 = use_man ? man_p2 : auto_p2;
	wire arm_req = (use_man | auto_req) & ~bus_off;

	wire man_scl_oe, man_sda_oe, man_sda_rel;
	wire i2c_done, i2c_ack, i2c_idle;
	wire [7:0] i2c_seen;
	reg probe_pulse;
	reg probe_busy;
	reg mcu_ok;
	arm_i2c #(.HALF(ARM_CLKS)) u_i2c (
		.clk(clk), .rst_n(rst_n), .req(arm_req), .probe(probe_pulse), .stat(stat_pulse),
		.cmd(arm_cmd), .p0(arm_p0), .p1(arm_p1), .p2(arm_p2),
		.scl_i(arm_scl_i), .sda_i(arm_sda_i),
		.scl_oe(man_scl_oe), .sda_oe(man_sda_oe), .sda_rel(man_sda_rel),
		.done(i2c_done), .ack_ok(i2c_ack), .seen(i2c_seen), .idle(i2c_idle)
	);
	assign arm_scl_oe = bus_off ? 1'b0 : man_scl_oe;
	assign arm_sda_oe = bus_off ? 1'b0 : man_sda_oe;
	assign arm_sda_rel = bus_off ? 1'b0 : man_sda_rel;

	wire g_ready, c_ready, s_ready, cal_done;
	wire [7:0] cal_r, cal_g, cal_b;
	wire [7:0] g_kind;
	wire [15:0] g_cx, g_cy;
	wire [19:0] g_area;
	wire c_vr, c_vg, c_vb;
	wire [15:0] c_xr, c_yr, c_xg, c_yg, c_xb, c_yb, c_ar, c_ag, c_ab;
	wire s_v0, s_v1, s_v2, s_sq0, s_sq1, s_sq2;
	wire [15:0] s_x0, s_y0, s_x1, s_y1, s_x2, s_y2;
	reg			sh_have;
	reg [7:0]	sh_r, sh_g, sh_b;

	gest_rep #(
		.ROI_X0(320), .ROI_Y0(300), .ROI_X1(1600), .ROI_Y1(900),
		.MIN_AREA(MIN_AREA), .PALM_AREA(PALM_AREA),
		.GAIN_R(GAIN_R), .GAIN_G(GAIN_G), .GAIN_B(GAIN_B)
	) u_gest (
		.clk(clk), .rst_n(rst_n), .vs(vs), .de(de), .y_off(y_off), .r(r), .g(g), .b(b),
		.ready(g_ready), .kind(g_kind), .cx(g_cx), .cy(g_cy), .area(g_area),
		.box_ok(g_box), .bx0(g_bx0), .bx1(g_bx1), .by0(g_by0), .by1(g_by1),
		.cap_arm(cap_pulse), .cal_done(cal_done), .cal_r(cal_r), .cal_g(cal_g), .cal_b(cal_b)
	);
	color_rep #(
		.ROI_X0(ROI_X0), .ROI_Y0(ROI_Y0), .ROI_X1(ROI_X1), .ROI_Y1(ROI_Y1),
		.MIN_AREA(MIN_AREA), .GAIN_R(GAIN_R), .GAIN_G(GAIN_G), .GAIN_B(GAIN_B)
	) u_color (
		.clk(clk), .rst_n(rst_n), .vs(vs), .de(de), .y_off(y_off), .r(r), .g(g), .b(b),
		.thr_r(thr_r), .thr_g(thr_g), .thr_b(thr_b), .stab(stab),
		.auto_on(auto_on),
		.rr(ref_rr), .rg(ref_rg), .rb(ref_rb),
		.gr(ref_gr), .gg(ref_gg), .gb(ref_gb),
		.brf(ref_br), .bgf(ref_bg), .bbf(ref_bb),
		.kr(ref_kr), .kg(ref_kg), .kb(ref_kb),
		.ready(c_ready), .vr(c_vr), .vg(c_vg), .vb(c_vb),
		.cx_r(c_xr), .cy_r(c_yr), .cx_g(c_xg), .cy_g(c_yg), .cx_b(c_xb), .cy_b(c_yb),
		.ar(c_ar), .ag(c_ag), .ab(c_ab)
	);
	shape2 #(
		.ROI_X0(ROI_X0), .ROI_Y0(ROI_Y0), .ROI_X1(ROI_X1), .ROI_Y1(ROI_Y1),
		.MIN_AREA(MIN_AREA), .SEP(SEP),
		.GAIN_R(GAIN_R), .GAIN_G(GAIN_G), .GAIN_B(GAIN_B)
	) u_shape (
		.clk(clk), .rst_n(rst_n), .vs(vs), .de(de), .y_off(y_off), .r(r), .g(g), .b(b),
		.got(sh_have), .oref(sh_r), .ogref(sh_g), .obref(sh_b),
		.ready(s_ready), .v0(s_v0), .v1(s_v1), .v2(s_v2), .sq0(s_sq0), .sq1(s_sq1), .sq2(s_sq2),
		.cx0(s_x0), .cy0(s_y0), .cx1(s_x1), .cy1(s_y1), .cx2(s_x2), .cy2(s_y2),
		.x0a(sh_x0a), .x0b(sh_x0b), .y0a(sh_y0a), .y0b(sh_y0b),
		.x1a(sh_x1a), .x1b(sh_x1b), .y1a(sh_y1a), .y1b(sh_y1b),
		.x2a(sh_x2a), .x2b(sh_x2b), .y2a(sh_y2a), .y2b(sh_y2b)
	);
	assign stage_o = stage;
	assign sh_got = sh_have && ((stage == 3'd3) || (stage == 3'd6));
	assign sh_v0 = s_v0;
	assign sh_sq0 = s_sq0;
	assign sh_v1 = s_v1;
	assign sh_sq1 = s_sq1;
	assign sh_v2 = s_v2;
	assign sh_sq2 = s_sq2;

	wire shape_on = s_v0 | s_v1;
	wire shape_sq = s_v0 ? s_sq0 : s_sq1;
	wire [7:0] shape_now = shape_on ? (shape_sq ? 8'd22 : 8'd21) : 8'd0;

	reg [7:0] mb [0:63];
	reg [6:0] mlen, mi;
	reg mbusy;
	reg tx_arm;
	reg tx_start;
	reg [7:0] tx_data;
	wire tx_busy;
	uart_tx #(.CLKS_PER_BIT(DBG_CLKS)) u_tx (
		.clk(clk), .rst_n(rst_n), .start(tx_start), .data(tx_data),
		.tx(dbg_tx), .busy(tx_busy)
	);

	reg [31:0] hb;
	reg banner;
	reg [2:0] banner_st;
	reg vpend;
	reg npend;
	reg [7:0] vcode, vtag;
	reg apend;
	reg astop;
	reg ahex;
	reg [7:0] ac0, ac1, agrp;
	reg kpend;
	reg kack;
	reg [7:0] kseen;
	integer k;
	reg [455:0] wide;
	reg [111:0] one;

	wire [7:0] col_r, col_g, col_b, shp0, shp1, shp2;
	near_slot u_nr (
		.clk(clk), .rst_n(rst_n), .ok(c_vr), .x(c_xr), .y(c_yr),
		.lv(slot_lv), .lx(slot_lx), .ly(slot_ly),
		.mv(slot_mv), .mx(slot_mx), .my(slot_my),
		.rv(slot_rv), .rx(slot_rx), .ry(slot_ry), .near(col_r)
	);
	near_slot u_ng (
		.clk(clk), .rst_n(rst_n), .ok(c_vg), .x(c_xg), .y(c_yg),
		.lv(slot_lv), .lx(slot_lx), .ly(slot_ly),
		.mv(slot_mv), .mx(slot_mx), .my(slot_my),
		.rv(slot_rv), .rx(slot_rx), .ry(slot_ry), .near(col_g)
	);
	near_slot u_nb (
		.clk(clk), .rst_n(rst_n), .ok(c_vb), .x(c_xb), .y(c_yb),
		.lv(slot_lv), .lx(slot_lx), .ly(slot_ly),
		.mv(slot_mv), .mx(slot_mx), .my(slot_my),
		.rv(slot_rv), .rx(slot_rx), .ry(slot_ry), .near(col_b)
	);
	near_slot u_n0 (
		.clk(clk), .rst_n(rst_n), .ok(s_v0), .x(s_x0), .y(s_y0),
		.lv(slot_lv), .lx(slot_lx), .ly(slot_ly),
		.mv(slot_mv), .mx(slot_mx), .my(slot_my),
		.rv(slot_rv), .rx(slot_rx), .ry(slot_ry), .near(shp0)
	);
	near_slot u_n1 (
		.clk(clk), .rst_n(rst_n), .ok(s_v1), .x(s_x1), .y(s_y1),
		.lv(slot_lv), .lx(slot_lx), .ly(slot_ly),
		.mv(slot_mv), .mx(slot_mx), .my(slot_my),
		.rv(slot_rv), .rx(slot_rx), .ry(slot_ry), .near(shp1)
	);
	near_slot u_n2 (
		.clk(clk), .rst_n(rst_n), .ok(s_v2), .x(s_x2), .y(s_y2),
		.lv(slot_lv), .lx(slot_lx), .ly(slot_ly),
		.mv(slot_mv), .mx(slot_mx), .my(slot_my),
		.rv(slot_rv), .rx(slot_rx), .ry(slot_ry), .near(shp2)
	);
	wire [7:0] jnear = (vcode_now == 8'h31) ? col_g : (vcode_now == 8'h32) ? col_b : col_r;
	wire want_sq = (vcode_now == 8'h41);
	wire s0ok = s_v0 && (s_sq0 == want_sq);
	wire s1ok = s_v1 && (s_sq1 == want_sq) && !s0ok;
	wire s2ok = s_v2 && (s_sq2 == want_sq) && !s0ok && !s1ok;
	wire [7:0] snear = s0ok ? shp0 : s1ok ? shp1 : s2ok ? shp2 : "Z";
	wire c0ok = s_v0 && (s_sq0 == chain_sq);
	wire c1ok = s_v1 && (s_sq1 == chain_sq) && !c0ok;
	wire c2ok = s_v2 && (s_sq2 == chain_sq) && !c0ok && !c1ok;
	wire [7:0] cnear = c0ok ? shp0 : c1ok ? shp1 : c2ok ? shp2 : "Z";

	function [7:0] at_bal;
		input [7:0] pix;
		input [8:0] gain;
		reg [16:0] m;
		begin
			m = pix * gain;
			at_bal = (m[16:8] > 9'd255) ? 8'd255 : m[15:8];
		end
	endfunction

	function at_near;
		input [11:0] px, py, cx, cy;
		reg signed [12:0] dx, dy;
		begin
			dx = $signed({1'b0, px}) - $signed({1'b0, cx});
			dy = $signed({1'b0, py}) - $signed({1'b0, cy});
			at_near = (dx >= -13'sd10) && (dx <= 13'sd10) && (dy >= -13'sd10) && (dy <= 13'sd10);
		end
	endfunction

	wire [7:0] at_sr = at_bal(r, GAIN_R);
	wire [7:0] at_sg = at_bal(g, GAIN_G);
	wire [7:0] at_sb = at_bal(b, GAIN_B);
	wire signed [12:0] at_top = $signed({1'b0, 12'd300}) + y_off + 13'sd16;
	wire [11:0] at_bx = 12'd1403;
	wire [11:0] at_by = at_top[11:0];
	wire [415:0] at_pack = {
		"AT ",
		dec3b(at_blank ? 8'd0 : ref_rr), " ", dec3b(at_blank ? 8'd0 : ref_rg), " ", dec3b(at_blank ? 8'd0 : ref_rb), " ",
		dec3b(at_blank ? 8'd0 : ref_gr), " ", dec3b(at_blank ? 8'd0 : ref_gg), " ", dec3b(at_blank ? 8'd0 : ref_gb), " ",
		dec3b(at_blank ? 8'd0 : ref_br), " ", dec3b(at_blank ? 8'd0 : ref_bg), " ", dec3b(at_blank ? 8'd0 : ref_bb), " ",
		dec3b(at_blank ? 8'd0 : ref_kr), " ", dec3b(at_blank ? 8'd0 : ref_kg), " ", dec3b(at_blank ? 8'd0 : ref_kb),
		8'h0D, 8'h0A
	};

	reg samp_wait, samp_run;
	reg at_vs, at_de;
	reg [11:0] at_x, at_y;
	wire at_bg = (at_x >= at_bx) && (at_x < at_bx + 12'd21) && (at_y >= at_by) && (at_y < at_by + 12'd21);
	reg [17:0] srr, srg, srb, sgr, sgg, sgb, sbr, sbg, sbb, skr, skg, skb;
	reg [9:0] nr, ng, nb, nk;
	reg at_ready;
	reg at_blank;
	reg at_seen;
	reg at_st;
	reg [3:0] at_i;
	reg at_div_start;
	reg [31:0] at_div_n;
	reg [19:0] at_div_d;
	wire [15:0] at_div_q;
	wire at_div_done;
	wire [7:0] at_byte = (at_div_q > 16'd255) ? 8'd255 : at_div_q[7:0];

	function sp_color;
		input [7:0] a, b, c;
		reg [7:0] hi, lo;
		reg [8:0] span;
		begin
			hi = (a >= b && a >= c) ? a : ((b >= c) ? b : c);
			lo = (a <= b && a <= c) ? a : ((b <= c) ? b : c);
			span = {1'b0, hi} - {1'b0, lo};
			sp_color = (span * 9'd3) > {1'b0, hi};
		end
	endfunction

	reg sp_wait, sp_run, sp_st, sp_ready, sp_blank, sp_lok, sp_rok;
	reg sp_seen;
	reg [3:0] sp_i;
	reg [17:0] plr, plg, plb, prr, prg, prb, pkr, pkg, pkb;
	reg [9:0] pnl, pnr, pnk;
	reg [7:0] ql_r, ql_g, ql_b, qr_r, qr_g, qr_b, qk_r, qk_g, qk_b;
	wire [455:0] sp_pack = {
		"SP ",
		dec3b(sp_blank ? 8'd0 : ql_r), " ", dec3b(sp_blank ? 8'd0 : ql_g), " ", dec3b(sp_blank ? 8'd0 : ql_b), " ",
		dec3b(sp_blank ? 8'd0 : qr_r), " ", dec3b(sp_blank ? 8'd0 : qr_g), " ", dec3b(sp_blank ? 8'd0 : qr_b), " ",
		dec3b(sp_blank ? 8'd0 : qk_r), " ", dec3b(sp_blank ? 8'd0 : qk_g), " ", dec3b(sp_blank ? 8'd0 : qk_b), " ",
		"OBJ ",
		dec3b(sh_have ? sh_r : 8'd0), " ", dec3b(sh_have ? sh_g : 8'd0), " ", dec3b(sh_have ? sh_b : 8'd0), " ",
		8'h0D, 8'h0A
	};

	div_u32 u_at (
		.clk(clk), .rst_n(rst_n), .start(at_div_start),
		.dividend(at_div_n), .divisor(at_div_d),
		.quotient(at_div_q), .done(at_div_done)
	);

	always @(posedge clk) begin
		if (!rst_n) begin
			samp_wait <= 1'b0;
			samp_run <= 1'b0;
			at_vs <= 1'b0;
			at_de <= 1'b0;
			at_x <= 12'd0;
			at_y <= 12'd0;
			srr <= 18'd0; srg <= 18'd0; srb <= 18'd0;
			sgr <= 18'd0; sgg <= 18'd0; sgb <= 18'd0;
			sbr <= 18'd0; sbg <= 18'd0; sbb <= 18'd0;
			skr <= 18'd0; skg <= 18'd0; skb <= 18'd0;
			nr <= 10'd0; ng <= 10'd0; nb <= 10'd0; nk <= 10'd0;
			auto_on <= 1'b1;
			ref_rr <= 8'd101; ref_rg <= 8'd47; ref_rb <= 8'd48;
			ref_gr <= 8'd144; ref_gg <= 8'd147; ref_gb <= 8'd92;
			ref_br <= 8'd37; ref_bg <= 8'd50; ref_bb <= 8'd79;
			ref_kr <= 8'd171; ref_kg <= 8'd170; ref_kb <= 8'd166;
			at_ready <= 1'b0;
			at_blank <= 1'b0;
			at_st <= 1'b0;
			at_i <= 4'd0;
			at_div_start <= 1'b0;
			at_div_n <= 32'd0;
			at_div_d <= 20'd0;
			sp_wait <= 1'b0;
			sp_run <= 1'b0;
			sp_st <= 1'b0;
			sp_ready <= 1'b0;
			sp_blank <= 1'b0;
			sp_lok <= 1'b0;
			sp_rok <= 1'b0;
			sp_i <= 4'd0;
			plr <= 18'd0; plg <= 18'd0; plb <= 18'd0;
			prr <= 18'd0; prg <= 18'd0; prb <= 18'd0;
			pkr <= 18'd0; pkg <= 18'd0; pkb <= 18'd0;
			pnl <= 10'd0; pnr <= 10'd0; pnk <= 10'd0;
			ql_r <= 8'd0; ql_g <= 8'd0; ql_b <= 8'd0;
			qr_r <= 8'd0; qr_g <= 8'd0; qr_b <= 8'd0;
			qk_r <= 8'd0; qk_g <= 8'd0; qk_b <= 8'd0;
			sh_have <= 1'b1;
			sh_r <= 8'd222; sh_g <= 8'd107; sh_b <= 8'd95;
		end else begin
			at_div_start <= 1'b0;
			at_vs <= vs;
			at_de <= de;
			if (dbg_v && (dbg_byte == "a") && (ywait == 2'd0) && (cwait == 3'd0) && !bwait && !mwait
				&& !samp_wait && !samp_run && !at_st && !sp_wait && !sp_run && !sp_st)
				samp_wait <= 1'b1;
			if (dbg_v && (dbg_byte == "p") && (ywait == 2'd0) && (cwait == 3'd0) && !bwait && !mwait
				&& !samp_wait && !samp_run && !at_st && !sp_wait && !sp_run && !sp_st)
				sp_wait <= 1'b1;
			if (at_vs && !vs) begin
				at_x <= 12'd0;
				at_y <= 12'd0;
				if (samp_run) begin
					samp_run <= 1'b0;
					if ((nr < 10'd200) || (ng < 10'd200) || (nb < 10'd200) || (nk < 10'd200)) begin
						at_blank <= 1'b1;
						at_ready <= 1'b1;
					end else begin
						at_i <= 4'd0;
						at_div_n <= {14'd0, srr};
						at_div_d <= {10'd0, nr};
						at_div_start <= 1'b1;
						at_st <= 1'b1;
					end
				end else if (samp_wait) begin
					samp_wait <= 1'b0;
					samp_run <= 1'b1;
					srr <= 18'd0; srg <= 18'd0; srb <= 18'd0;
					sgr <= 18'd0; sgg <= 18'd0; sgb <= 18'd0;
					sbr <= 18'd0; sbg <= 18'd0; sbb <= 18'd0;
					skr <= 18'd0; skg <= 18'd0; skb <= 18'd0;
					nr <= 10'd0; ng <= 10'd0; nb <= 10'd0; nk <= 10'd0;
				end else if (sp_wait) begin
					sp_wait <= 1'b0;
					sp_run <= 1'b1;
					plr <= 18'd0; plg <= 18'd0; plb <= 18'd0;
					prr <= 18'd0; prg <= 18'd0; prb <= 18'd0;
					pkr <= 18'd0; pkg <= 18'd0; pkb <= 18'd0;
					pnl <= 10'd0; pnr <= 10'd0; pnk <= 10'd0;
				end else if (sp_run) begin
					sp_run <= 1'b0;
					sp_lok <= (pnl >= 10'd200);
					sp_rok <= (pnr >= 10'd200);
					if ((pnk < 10'd200) || ((pnl < 10'd200) && (pnr < 10'd200))) begin
						sp_blank <= 1'b1;
						sp_ready <= 1'b1;
						sh_have <= 1'b0;
					end else begin
						sp_blank <= 1'b0;
						sp_i <= 4'd0;
						at_div_n <= (pnl >= 10'd200) ? {14'd0, plr} : 32'd0;
						at_div_d <= (pnl >= 10'd200) ? {10'd0, pnl} : 20'd1;
						at_div_start <= 1'b1;
						sp_st <= 1'b1;
					end
				end
			end else begin
				if (de) begin
					if (samp_run) begin
						if (at_near(at_x, at_y, slot_lx[11:0], slot_ly[11:0])) begin
							srr <= srr + {10'd0, at_sr};
							srg <= srg + {10'd0, at_sg};
							srb <= srb + {10'd0, at_sb};
							nr <= nr + 10'd1;
						end
						if (at_near(at_x, at_y, slot_mx[11:0], slot_my[11:0])) begin
							sgr <= sgr + {10'd0, at_sr};
							sgg <= sgg + {10'd0, at_sg};
							sgb <= sgb + {10'd0, at_sb};
							ng <= ng + 10'd1;
						end
						if (at_near(at_x, at_y, slot_rx[11:0], slot_ry[11:0])) begin
							sbr <= sbr + {10'd0, at_sr};
							sbg <= sbg + {10'd0, at_sg};
							sbb <= sbb + {10'd0, at_sb};
							nb <= nb + 10'd1;
						end
						if (at_bg) begin
							skr <= skr + {10'd0, at_sr};
							skg <= skg + {10'd0, at_sg};
							skb <= skb + {10'd0, at_sb};
							nk <= nk + 10'd1;
						end
					end
					if (sp_run) begin
						if (at_near(at_x, at_y, slot_lx[11:0], slot_ly[11:0])) begin
							plr <= plr + {10'd0, at_sr};
							plg <= plg + {10'd0, at_sg};
							plb <= plb + {10'd0, at_sb};
							pnl <= pnl + 10'd1;
						end
						if (at_near(at_x, at_y, slot_rx[11:0], slot_ry[11:0])) begin
							prr <= prr + {10'd0, at_sr};
							prg <= prg + {10'd0, at_sg};
							prb <= prb + {10'd0, at_sb};
							pnr <= pnr + 10'd1;
						end
						if (at_bg) begin
							pkr <= pkr + {10'd0, at_sr};
							pkg <= pkg + {10'd0, at_sg};
							pkb <= pkb + {10'd0, at_sb};
							pnk <= pnk + 10'd1;
						end
					end
					at_x <= at_x + 12'd1;
				end else if (at_de) begin
					at_x <= 12'd0;
					at_y <= at_y + 12'd1;
				end
			end
			if (at_st && at_div_done) begin
				case (at_i)
					4'd0: ref_rr <= at_byte;
					4'd1: ref_rg <= at_byte;
					4'd2: ref_rb <= at_byte;
					4'd3: ref_gr <= at_byte;
					4'd4: ref_gg <= at_byte;
					4'd5: ref_gb <= at_byte;
					4'd6: ref_br <= at_byte;
					4'd7: ref_bg <= at_byte;
					4'd8: ref_bb <= at_byte;
					4'd9: ref_kr <= at_byte;
					4'd10: ref_kg <= at_byte;
					default: ref_kb <= at_byte;
				endcase
				if (at_i == 4'd11) begin
					at_st <= 1'b0;
					at_blank <= 1'b0;
					auto_on <= 1'b1;
					at_ready <= 1'b1;
				end else begin
					at_i <= at_i + 4'd1;
					at_div_start <= 1'b1;
					case (at_i)
						4'd0: begin at_div_n <= {14'd0, srg}; at_div_d <= {10'd0, nr}; end
						4'd1: begin at_div_n <= {14'd0, srb}; at_div_d <= {10'd0, nr}; end
						4'd2: begin at_div_n <= {14'd0, sgr}; at_div_d <= {10'd0, ng}; end
						4'd3: begin at_div_n <= {14'd0, sgg}; at_div_d <= {10'd0, ng}; end
						4'd4: begin at_div_n <= {14'd0, sgb}; at_div_d <= {10'd0, ng}; end
						4'd5: begin at_div_n <= {14'd0, sbr}; at_div_d <= {10'd0, nb}; end
						4'd6: begin at_div_n <= {14'd0, sbg}; at_div_d <= {10'd0, nb}; end
						4'd7: begin at_div_n <= {14'd0, sbb}; at_div_d <= {10'd0, nb}; end
						4'd8: begin at_div_n <= {14'd0, skr}; at_div_d <= {10'd0, nk}; end
						4'd9: begin at_div_n <= {14'd0, skg}; at_div_d <= {10'd0, nk}; end
						default: begin at_div_n <= {14'd0, skb}; at_div_d <= {10'd0, nk}; end
					endcase
				end
			end
			if (sp_st && at_div_done) begin
				case (sp_i)
					4'd0: ql_r <= at_byte;
					4'd1: ql_g <= at_byte;
					4'd2: ql_b <= at_byte;
					4'd3: qr_r <= at_byte;
					4'd4: qr_g <= at_byte;
					4'd5: qr_b <= at_byte;
					4'd6: qk_r <= at_byte;
					4'd7: qk_g <= at_byte;
					default: qk_b <= at_byte;
				endcase
				if (sp_i == 4'd8) begin
					sp_st <= 1'b0;
					sp_ready <= 1'b1;
					if (sp_lok && sp_color(ql_r, ql_g, ql_b) && sp_rok && sp_color(qr_r, qr_g, qr_b)) begin
						sh_have <= 1'b1;
						sh_r <= ({1'b0, ql_r} + qr_r) >> 1;
						sh_g <= ({1'b0, ql_g} + qr_g) >> 1;
						sh_b <= ({1'b0, ql_b} + qr_b) >> 1;
					end else if (sp_lok && sp_color(ql_r, ql_g, ql_b)) begin
						sh_have <= 1'b1;
						sh_r <= ql_r;
						sh_g <= ql_g;
						sh_b <= ql_b;
					end else if (sp_rok && sp_color(qr_r, qr_g, qr_b)) begin
						sh_have <= 1'b1;
						sh_r <= qr_r;
						sh_g <= qr_g;
						sh_b <= qr_b;
					end else
						sh_have <= 1'b0;
				end else begin
					sp_i <= sp_i + 4'd1;
					at_div_start <= 1'b1;
					case (sp_i)
						4'd0: begin at_div_n <= {14'd0, plg}; at_div_d <= sp_lok ? {10'd0, pnl} : 20'd1; end
						4'd1: begin at_div_n <= {14'd0, plb}; at_div_d <= sp_lok ? {10'd0, pnl} : 20'd1; end
						4'd2: begin at_div_n <= sp_rok ? {14'd0, prr} : 32'd0; at_div_d <= sp_rok ? {10'd0, pnr} : 20'd1; end
						4'd3: begin at_div_n <= sp_rok ? {14'd0, prg} : 32'd0; at_div_d <= sp_rok ? {10'd0, pnr} : 20'd1; end
						4'd4: begin at_div_n <= sp_rok ? {14'd0, prb} : 32'd0; at_div_d <= sp_rok ? {10'd0, pnr} : 20'd1; end
						4'd5: begin at_div_n <= {14'd0, pkr}; at_div_d <= {10'd0, pnk}; end
						4'd6: begin at_div_n <= {14'd0, pkg}; at_div_d <= {10'd0, pnk}; end
						default: begin at_div_n <= {14'd0, pkb}; at_div_d <= {10'd0, pnk}; end
					endcase
				end
			end
			if (at_seen) begin
				at_ready <= 1'b0;
				at_blank <= 1'b0;
			end
			if (sp_seen) begin
				sp_ready <= 1'b0;
				sp_blank <= 1'b0;
			end
		end
	end

	reg wb_req;
	reg wpend;
	reg [1:0] wb_st;
	reg [8:0] gain_r, gain_g, gain_b;
	reg [7:0] raw_r, raw_g, raw_b;
	reg div_start;
	reg [31:0] div_n;
	reg [19:0] div_d;
	wire [15:0] div_q;
	wire div_done;
	div_u32 u_wb (
		.clk(clk), .rst_n(rst_n), .start(div_start),
		.dividend(div_n), .divisor(div_d), .quotient(div_q), .done(div_done)
	);

	always @(posedge clk) begin
		if (!rst_n) begin
			stage <= 3'd1;
			ywait <= 2'd0;
			yhi <= 8'd0;
			y_off <= 12'sd110;
			cwait <= 3'd0;
			bwait <= 1'b0;
			thr_r <= 8'd70;
			thr_g <= 8'd24;
			thr_b <= 8'd24;
			stab <= 8'd16;
			c_r <= 8'd0;
			c_g <= 8'd0;
			c_b <= 8'd0;
			mwait <= 1'b0;
			slot_lv <= 1'b1;
			slot_mv <= 1'b1;
			slot_rv <= 1'b1;
			slot_lx <= 16'd744;
			slot_ly <= 16'd687;
			slot_mx <= 16'd938;
			slot_my <= 16'd677;
			slot_rx <= 16'd1138;
			slot_ry <= 16'd666;
			jpend <= 1'b0;
			jcol <= 8'd0;
			jslot <= 8'd0;
			chain_on <= 1'b0;
			chain_sq <= 1'b0;
			chain_dly <= 32'd0;
			grab_on <= 1'b0;
			grab_shot <= 1'b0;
			grab_p0 <= 8'd0;
			grab_p1 <= 8'd0;
			grab_dly <= 30'd0;
			grab_hold <= 1'b0;
			tmo_run <= 1'b0;
			grab_tmo <= 32'd0;
			voice_keep <= 1'b0;
			voice_replay <= 1'b0;
			stat_pulse <= 1'b0;
			stat_busy <= 1'b0;
			stat_toss <= 1'b0;
			keep_code <= 8'd0;
			keep_tag <= 8'd0;
			mlen <= 7'd0;
			mi <= 7'd0;
			mbusy <= 1'b0;
			tx_arm <= 1'b0;
			tx_start <= 1'b0;
			tx_data <= 8'd0;
			hb <= 32'd0;
			banner <= 1'b1;
			banner_st <= 3'd1;
			vpend <= 1'b0;
			npend <= 1'b0;
			vcode <= 8'd0;
			vtag <= 8'd0;
			apend <= 1'b0;
			astop <= 1'b0;
			ahex <= 1'b0;
			ac0 <= 8'd0;
			ac1 <= 8'd0;
			agrp <= 8'd0;
			armed <= 1'b0;
			bus_off <= 1'b0;
			home_pulse <= 1'b0;
			home_to5 <= 1'b0;
			home_need <= 1'b0;
			home_wait <= 1'b0;
			home_busy <= 1'b0;
			home_second <= 1'b0;
			home_gap <= 2'd0;
			off_dly <= 30'd0;
			home_dly <= 30'd0;
			auto_req <= 1'b0;
			auto_echo <= 1'b0;
			auto_hex <= 1'b0;
			auto_stop <= 1'b0;
			auto_cmd <= 8'd0;
			auto_p0 <= 8'd0;
			auto_p1 <= 8'd0;
			auto_p2 <= 8'd0;
			auto_c0 <= 8'd0;
			auto_c1 <= 8'd0;
			auto_grp <= 8'd0;
			hold_kind <= "N";
			last_shape <= 8'd0;
			cool <= 5'd0;
			gpend <= 1'b0;
			hpend <= 1'b0;
			cap_pulse <= 1'b0;
			samp_on <= 1'b0;
			hr <= 8'd0;
			hg <= 8'd0;
			hb <= 8'd0;
			gk <= "N";
			gx <= 16'd0;
			gy <= 16'd0;
			ga <= 20'd0;
			gseen <= "N";
			gsent <= 8'h00;
			gcnt <= 4'd0;
			gphase <= 2'd0;
			kpend <= 1'b0;
			kack <= 1'b0;
			kseen <= 8'd0;
			probe_pulse <= 1'b0;
			probe_busy <= 1'b0;
			mcu_ok <= 1'b0;
			wb_req <= 1'b0;
			wpend <= 1'b0;
			at_seen <= 1'b0;
			sp_seen <= 1'b0;
			wb_st <= 2'd0;
			gain_r <= 9'd0;
			gain_g <= 9'd0;
			gain_b <= 9'd0;
			raw_r <= 8'd0;
			raw_g <= 8'd0;
			raw_b <= 8'd0;
			div_start <= 1'b0;
			div_n <= 32'd0;
			div_d <= 20'd0;
		end else begin
			tx_start <= 1'b0;
			cap_pulse <= 1'b0;
			auto_req <= 1'b0;
			auto_echo <= 1'b0;
			probe_pulse <= 1'b0;
			stat_pulse <= 1'b0;
			voice_replay <= 1'b0;
			div_start <= 1'b0;
			if (off_dly != 30'd0) begin
				off_dly <= off_dly - 30'd1;
				if (off_dly == 30'd1)
					bus_off <= 1'b1;
			end
			if (!at_ready)
				at_seen <= 1'b0;
			if (!sp_ready)
				sp_seen <= 1'b0;
			if (wb_req) begin
				wb_req <= 1'b0;
				raw_r <= paper_r;
				raw_g <= paper_g;
				raw_b <= paper_b;
				if ((paper_r == 8'd0) || (paper_g == 8'd0) || (paper_b == 8'd0)) begin
					gain_r <= 9'd0;
					gain_g <= 9'd0;
					gain_b <= 9'd0;
					wb_st <= 2'd0;
					wpend <= 1'b1;
				end else begin
					div_n <= {16'd0, paper_g, 8'd0};
					div_d <= {12'd0, paper_r};
					div_start <= 1'b1;
					wb_st <= 2'd1;
				end
			end else if ((wb_st == 2'd1) && div_done) begin
				gain_r <= clamp_gain(div_q);
				div_n <= {16'd0, raw_g, 8'd0};
				div_d <= {12'd0, raw_b};
				div_start <= 1'b1;
				wb_st <= 2'd2;
			end else if ((wb_st == 2'd2) && div_done) begin
				gain_b <= clamp_gain(div_q);
				gain_g <= 9'd256;
				wb_st <= 2'd0;
				wpend <= 1'b1;
			end
			if (tx_busy)
				tx_arm <= 1'b0;
			if (dbg_v && mwait) begin
				mwait <= 1'b0;
				if ((dbg_byte == "1" || dbg_byte == "2" || dbg_byte == "3") && (c_vr || c_vg || c_vb)) begin
					if (dbg_byte == "1") begin
						slot_lv <= 1'b1;
						slot_lx <= (c_vr && (!c_vg || (c_ar >= c_ag)) && (!c_vb || (c_ar >= c_ab))) ? c_xr :
							(c_vg && (!c_vb || (c_ag >= c_ab))) ? c_xg : c_xb;
						slot_ly <= (c_vr && (!c_vg || (c_ar >= c_ag)) && (!c_vb || (c_ar >= c_ab))) ? c_yr :
							(c_vg && (!c_vb || (c_ag >= c_ab))) ? c_yg : c_yb;
					end else if (dbg_byte == "2") begin
						slot_mv <= 1'b1;
						slot_mx <= (c_vr && (!c_vg || (c_ar >= c_ag)) && (!c_vb || (c_ar >= c_ab))) ? c_xr :
							(c_vg && (!c_vb || (c_ag >= c_ab))) ? c_xg : c_xb;
						slot_my <= (c_vr && (!c_vg || (c_ar >= c_ag)) && (!c_vb || (c_ar >= c_ab))) ? c_yr :
							(c_vg && (!c_vb || (c_ag >= c_ab))) ? c_yg : c_yb;
					end else begin
						slot_rv <= 1'b1;
						slot_rx <= (c_vr && (!c_vg || (c_ar >= c_ag)) && (!c_vb || (c_ar >= c_ab))) ? c_xr :
							(c_vg && (!c_vb || (c_ag >= c_ab))) ? c_xg : c_xb;
						slot_ry <= (c_vr && (!c_vg || (c_ar >= c_ag)) && (!c_vb || (c_ar >= c_ab))) ? c_yr :
							(c_vg && (!c_vb || (c_ag >= c_ab))) ? c_yg : c_yb;
					end
					jpend <= 1'b1;
					jcol <= "M";
					jslot <= dbg_byte;
				end else begin
					jpend <= 1'b1;
					jcol <= "M";
					jslot <= "0";
				end
			end else if (dbg_v && (ywait == 2'd2)) begin
				yhi <= dbg_byte;
				ywait <= 2'd1;
			end else if (dbg_v && (ywait == 2'd1)) begin
				ywait <= 2'd0;
				y_off <= yclamp({yhi, dbg_byte});
			end else if (dbg_v && (cwait != 3'd0)) begin
				if (cwait == 3'd4) begin
					c_r <= dbg_byte;
					cwait <= 3'd3;
				end else if (cwait == 3'd3) begin
					c_g <= dbg_byte;
					cwait <= 3'd2;
				end else if (cwait == 3'd2) begin
					c_b <= dbg_byte;
					cwait <= 3'd1;
				end else begin
					thr_r <= c_r;
					thr_g <= c_g;
					thr_b <= c_b;
					stab <= dbg_byte;
					cwait <= 3'd0;
				end
			end else if (dbg_v && (dbg_byte == "y"))
				ywait <= 2'd2;
			else if (dbg_v && (dbg_byte == "c"))
				cwait <= 3'd4;
			else if (dbg_v && bwait) begin
				bwait <= 1'b0;
				if (dbg_byte == "2")
					wb_req <= 1'b1;
			end else if (dbg_v && (dbg_byte == "b"))
				bwait <= 1'b1;
			else if (dbg_v && (dbg_byte == "m") && (stage == 3'd6))
				mwait <= 1'b1;
			else if (dbg_v && (dbg_byte == "i") && (stage == 3'd4))
				samp_on <= 1'b1;
			else if (dbg_v && (dbg_byte == "e") && (stage == 3'd4))
				samp_on <= 1'b0;
			else if (dbg_v && (dbg_byte == "h") && (stage == 3'd4) && samp_on)
				cap_pulse <= 1'b1;
			if (stage != 3'd4)
				samp_on <= 1'b0;
			if (dbg_v && (ywait == 2'd0) && (cwait == 3'd0) && !bwait && !mwait && (dbg_byte >= "1") && (dbg_byte <= "6")) begin
				stage <= dbg_byte - "0";
				banner <= 1'b1;
				banner_st <= dbg_byte - "0";
				if ((dbg_byte - "0") != stage) begin
					home_pulse <= 1'b1;
					home_to5 <= (dbg_byte == "5");
				end else if (dbg_byte == "5")
					bus_off <= 1'b1;
				else begin
					bus_off <= 1'b0;
					off_dly <= 30'd0;
				end
			end
			if (voice_use) begin
				if ((vtag_now == "V") && (vcode_now == 8'h01)) begin
					if (stage != 3'd1) begin home_pulse <= 1'b1; home_to5 <= 1'b0; end
					stage <= 3'd1; banner <= 1'b1; banner_st <= 3'd1;
				end
				if ((vtag_now == "V") && (vcode_now == 8'h02)) begin
					if (stage != 3'd2) begin home_pulse <= 1'b1; home_to5 <= 1'b0; end
					stage <= 3'd2; banner <= 1'b1; banner_st <= 3'd2;
				end
				if ((vtag_now == "V") && (vcode_now == 8'h03)) begin
					if (stage != 3'd3) begin home_pulse <= 1'b1; home_to5 <= 1'b0; end
					stage <= 3'd3; banner <= 1'b1; banner_st <= 3'd3;
				end
				if ((vtag_now == "V") && (vcode_now == 8'h04)) begin
					if (stage != 3'd4) begin home_pulse <= 1'b1; home_to5 <= 1'b0; end
					stage <= 3'd4; banner <= 1'b1; banner_st <= 3'd4;
				end
				if ((vtag_now == "V") && (vcode_now == 8'h05)) begin
					if (stage != 3'd5) begin home_pulse <= 1'b1; home_to5 <= 1'b1; end
					else bus_off <= 1'b1;
					stage <= 3'd5; banner <= 1'b1; banner_st <= 3'd5;
				end
				if ((vtag_now == "S") && (vcode_now == 8'h02)) begin
					if (stage != 3'd1) begin home_pulse <= 1'b1; home_to5 <= 1'b0; end
					stage <= 3'd1; banner <= 1'b1; banner_st <= 3'd1;
				end
				if ((vtag_now == "S") && (vcode_now == 8'h03)) begin
					if (stage != 3'd2) begin home_pulse <= 1'b1; home_to5 <= 1'b0; end
					stage <= 3'd2; banner <= 1'b1; banner_st <= 3'd2;
				end
				if ((vtag_now == "S") && (vcode_now == 8'h04)) begin
					if (stage != 3'd3) begin home_pulse <= 1'b1; home_to5 <= 1'b0; end
					stage <= 3'd3; banner <= 1'b1; banner_st <= 3'd3;
				end
				if ((vtag_now == "S") && (vcode_now == 8'h05)) begin
					if (stage != 3'd4) begin home_pulse <= 1'b1; home_to5 <= 1'b0; end
					stage <= 3'd4; banner <= 1'b1; banner_st <= 3'd4;
				end
				if ((vtag_now == "S") && (vcode_now == 8'h06)) begin
					if (stage != 3'd5) begin home_pulse <= 1'b1; home_to5 <= 1'b1; end
					else bus_off <= 1'b1;
					stage <= 3'd5; banner <= 1'b1; banner_st <= 3'd5;
				end
			end
			if (voice_use && ((stage == 3'd1) || (stage == 3'd2))) begin
				vpend <= 1'b1;
				vcode <= vcode_now;
				vtag <= vtag_now;
				if (!bus_off && (vtag_now == "V") && (vcode_now >= 8'h30) && (vcode_now <= 8'h32)) begin
					jpend <= 1'b1;
					jcol <= (vcode_now == 8'h30) ? "R" : (vcode_now == 8'h31) ? "G" : "B";
					jslot <= jnear;
					if ((jnear == "L") || (jnear == "M") || (jnear == "R")) begin
						grab_on <= 1'b1;
						grab_hold <= 1'b1;
						grab_shot <= 1'b0;
						grab_dly <= 30'd0;
						grab_p0 <= jnear;
						grab_p1 <= (vcode_now == 8'h30) ? "R" : (vcode_now == 8'h31) ? "G" : "B";
					end else
						grab_on <= 1'b0;
				end
			end
			if (voice_use && !bus_off && !home_hold && ((stage == 3'd1) || (stage == 3'd3)) && (vtag_now == "V")
				&& ((vcode_now == 8'h40) || (vcode_now == 8'h41))) begin
				vpend <= 1'b1;
				vcode <= vcode_now;
				vtag <= vtag_now;
				jpend <= 1'b1;
				jcol <= (vcode_now == 8'h40) ? "C" : "S";
				jslot <= snear;
				if ((snear == "L") || (snear == "M") || (snear == "R")) begin
					auto_req <= 1'b1;
					auto_cmd <= 8'h15;
					auto_p0 <= snear;
					auto_p1 <= (vcode_now == 8'h41) ? "R" : "G";
					auto_p2 <= 8'd0;
					chain_on <= 1'b1;
					chain_sq <= (vcode_now == 8'h41);
					chain_dly <= CHAIN_WAIT;
				end else
					chain_on <= 1'b0;
			end
			if ((stage != 3'd1) && (stage != 3'd3))
				chain_on <= 1'b0;
			else if (chain_on && !voice_got) begin
				if (chain_dly != 32'd0)
					chain_dly <= chain_dly - 32'd1;
				else if (!home_hold && !bus_off && ((cnear == "L") || (cnear == "M") || (cnear == "R"))) begin
					jpend <= 1'b1;
					jcol <= chain_sq ? "S" : "C";
					jslot <= cnear;
					auto_req <= 1'b1;
					auto_cmd <= 8'h15;
					auto_p0 <= cnear;
					auto_p1 <= chain_sq ? "R" : "G";
					auto_p2 <= 8'd0;
					chain_dly <= CHAIN_WAIT;
				end else
					chain_on <= 1'b0;
			end
			// 手势稳定约 8 帧后发一次。左/右是调试按键的左、右，走 6 号舵机。无手先复位，再把 2 号、6 号和夹爪收到复位脉宽。
			if (man_echo_v || auto_echo) begin
				apend <= 1'b1;
				if (man_echo_v) begin
					astop <= man_echo_stop;
					ahex <= man_echo_hex;
					ac0 <= man_c0;
					ac1 <= man_c1;
					agrp <= man_grp;
				end else begin
					astop <= auto_stop;
					ahex <= auto_hex;
					ac0 <= auto_c0;
					ac1 <= auto_c1;
					agrp <= auto_grp;
				end
			end
			if (i2c_done) begin
				if (!bus_off)
					mcu_ok <= i2c_ack;
				if (!probe_busy && !stat_busy && !bus_off) begin
					kpend <= 1'b1;
					kack <= i2c_ack;
					kseen <= i2c_seen;
				end
				probe_busy <= 1'b0;
				if (stat_toss)
					stat_toss <= 1'b0;
				else if (stat_busy) begin
					stat_busy <= 1'b0;
					if (i2c_ack && (i2c_seen == 8'h00)) begin
						grab_hold <= 1'b0;
						tmo_run <= 1'b0;
						if (voice_keep)
							voice_replay <= 1'b1;
						voice_keep <= 1'b0;
					end else
						voice_keep <= 1'b0;
				end
			end
			if ((hb == 32'd2) && i2c_idle && !bus_off && !stat_busy && !voice_keep) begin
				probe_pulse <= 1'b1;
				probe_busy <= 1'b1;
			end

			if (mbusy) begin
				if (!tx_busy && !tx_arm) begin
					tx_data <= mb[mi];
					tx_start <= 1'b1;
					tx_arm <= 1'b1;
					if (mi + 7'd1 >= mlen)
						mbusy <= 1'b0;
					else
						mi <= mi + 7'd1;
				end
			end else if (vpend) begin
				one = {vtag, hexd(vcode[7:4]), hexd(vcode[3:0]), 8'h0D, 8'h0A, 72'd0};
				for (k = 0; k < 5; k = k + 1)
					mb[k] <= one[111 - 8 * k -: 8];
				mlen <= 7'd5;
				mi <= 7'd0;
				mbusy <= 1'b1;
				vpend <= 1'b0;
			end else if (npend) begin
				mb[0] <= "N";
				mb[1] <= "S";
				mb[2] <= 8'h0D;
				mb[3] <= 8'h0A;
				mlen <= 7'd4;
				mi <= 7'd0;
				mbusy <= 1'b1;
				npend <= 1'b0;
			end else if (banner) begin
				mb[0] <= "D";
				mb[1] <= "0" + banner_st;
				mb[2] <= " ";
				mb[3] <= "V";
				mb[4] <= hexd(FW_VER[7:4]);
				mb[5] <= hexd(FW_VER[3:0]);
				mb[6] <= " ";
				mb[7] <= "P";
				mb[8] <= mcu_ok ? "1" : "0";
				mb[9] <= " ";
				mb[10] <= "A";
				mb[11] <= armed ? "1" : "0";
				mb[12] <= 8'h0D;
				mb[13] <= 8'h0A;
				mlen <= 7'd14;
				mi <= 7'd0;
				mbusy <= 1'b1;
				banner <= 1'b0;
				hb <= HB_CLKS;
			end else if (apend) begin
				if (astop)
					one = {"A", "S", "T", 8'h0D, 8'h0A, 72'd0};
				else if (ahex)
					one = {"A", hexd(agrp[7:4]), hexd(agrp[3:0]), 8'h0D, 8'h0A, 72'd0};
				else
					one = {"A", ac0, ac1, 8'h0D, 8'h0A, 72'd0};
				for (k = 0; k < 5; k = k + 1)
					mb[k] <= one[111 - 8 * k -: 8];
				mlen <= 7'd5;
				mi <= 7'd0;
				mbusy <= 1'b1;
				apend <= 1'b0;
			end else if (jpend) begin
				if (jcol == "M") begin
					if (jslot == "1")
						one = xyline("M", "1", slot_lx, slot_ly);
					else if (jslot == "2")
						one = xyline("M", "2", slot_mx, slot_my);
					else if (jslot == "3")
						one = xyline("M", "3", slot_rx, slot_ry);
					else
						one = xyline("M", "0", 16'd0, 16'd0);
					for (k = 0; k < 14; k = k + 1)
						mb[k] <= one[111 - 8 * k -: 8];
					mlen <= 7'd14;
				end else begin
					mb[0] <= "J";
					mb[1] <= " ";
					mb[2] <= jcol;
					mb[3] <= " ";
					mb[4] <= jslot;
					mb[5] <= 8'h0D;
					mb[6] <= 8'h0A;
					mlen <= 7'd7;
				end
				mi <= 7'd0;
				mbusy <= 1'b1;
				jpend <= 1'b0;
			end else if (kpend) begin
				mb[0] <= "K";
				mb[1] <= kack ? "1" : "0";
				mb[2] <= hexd(kseen[7:4]);
				mb[3] <= hexd(kseen[3:0]);
				mb[4] <= 8'h0D;
				mb[5] <= 8'h0A;
				mlen <= 7'd6;
				mi <= 7'd0;
				mbusy <= 1'b1;
				kpend <= 1'b0;
			end else if (hpend) begin
				mb[0] <= "H";
				mb[1] <= " ";
				mb[2] <= hexd(hr[7:4]);
				mb[3] <= hexd(hr[3:0]);
				mb[4] <= " ";
				mb[5] <= hexd(hg[7:4]);
				mb[6] <= hexd(hg[3:0]);
				mb[7] <= " ";
				mb[8] <= hexd(hb[7:4]);
				mb[9] <= hexd(hb[3:0]);
				mb[10] <= 8'h0D;
				mb[11] <= 8'h0A;
				mlen <= 7'd12;
				mi <= 7'd0;
				mbusy <= 1'b1;
				hpend <= 1'b0;
			end else if (gpend && !((stage == 3'd4) && g_ready)) begin
				mb[0] <= "G";
				mb[1] <= " ";
				mb[2] <= gk;
				mb[3] <= " ";
				mb[4] <= hexd(gx[15:12]);
				mb[5] <= hexd(gx[11:8]);
				mb[6] <= hexd(gx[7:4]);
				mb[7] <= hexd(gx[3:0]);
				mb[8] <= " ";
				mb[9] <= hexd(gy[15:12]);
				mb[10] <= hexd(gy[11:8]);
				mb[11] <= hexd(gy[7:4]);
				mb[12] <= hexd(gy[3:0]);
				mb[13] <= " ";
				mb[14] <= hexd(ga[19:16]);
				mb[15] <= hexd(ga[15:12]);
				mb[16] <= hexd(ga[11:8]);
				mb[17] <= hexd(ga[7:4]);
				mb[18] <= hexd(ga[3:0]);
				mb[19] <= 8'h0D;
				mb[20] <= 8'h0A;
				mlen <= 7'd21;
				mi <= 7'd0;
				mbusy <= 1'b1;
				gpend <= 1'b0;
			end else if (at_ready && !at_seen) begin
				for (k = 0; k < 52; k = k + 1)
					mb[k] <= at_pack[415 - 8 * k -: 8];
				mlen <= 7'd52;
				mi <= 7'd0;
				mbusy <= 1'b1;
				at_seen <= 1'b1;
			end else if (sp_ready && !sp_seen) begin
				for (k = 0; k < 57; k = k + 1)
					mb[k] <= sp_pack[455 - 8 * k -: 8];
				mlen <= 7'd57;
				mi <= 7'd0;
				mbusy <= 1'b1;
				sp_seen <= 1'b1;
			end else if (wpend) begin
				mb[0] <= "W";
				mb[1] <= "B";
				mb[2] <= " ";
				mb[3] <= dec4({1'b0, gain_r})[31:24];
				mb[4] <= dec4({1'b0, gain_r})[23:16];
				mb[5] <= dec4({1'b0, gain_r})[15:8];
				mb[6] <= dec4({1'b0, gain_r})[7:0];
				mb[7] <= " ";
				mb[8] <= dec4({1'b0, gain_g})[31:24];
				mb[9] <= dec4({1'b0, gain_g})[23:16];
				mb[10] <= dec4({1'b0, gain_g})[15:8];
				mb[11] <= dec4({1'b0, gain_g})[7:0];
				mb[12] <= " ";
				mb[13] <= dec4({1'b0, gain_b})[31:24];
				mb[14] <= dec4({1'b0, gain_b})[23:16];
				mb[15] <= dec4({1'b0, gain_b})[15:8];
				mb[16] <= dec4({1'b0, gain_b})[7:0];
				mb[17] <= " ";
				mb[18] <= dec3b(raw_r)[23:16];
				mb[19] <= dec3b(raw_r)[15:8];
				mb[20] <= dec3b(raw_r)[7:0];
				mb[21] <= " ";
				mb[22] <= dec3b(raw_g)[23:16];
				mb[23] <= dec3b(raw_g)[15:8];
				mb[24] <= dec3b(raw_g)[7:0];
				mb[25] <= " ";
				mb[26] <= dec3b(raw_b)[23:16];
				mb[27] <= dec3b(raw_b)[15:8];
				mb[28] <= dec3b(raw_b)[7:0];
				mb[29] <= 8'h0D;
				mb[30] <= 8'h0A;
				mlen <= 7'd31;
				mi <= 7'd0;
				mbusy <= 1'b1;
				wpend <= 1'b0;
			end else if (((stage == 3'd2) || (stage == 3'd6)) && c_ready) begin
				wide = {cline("R", c_vr, c_xr, c_yr, c_ar), cline("G", c_vg, c_xg, c_yg, c_ag), cline("B", c_vb, c_xb, c_yb, c_ab)};
				for (k = 0; k < 57; k = k + 1)
					mb[k] <= wide[455 - 8 * k -: 8];
				mlen <= 7'd57;
				mi <= 7'd0;
				mbusy <= 1'b1;
			end else if ((stage == 3'd3) && s_ready) begin
				wide[455:344] = xyline("Q", s_v0 ? (s_sq0 ? "S" : "C") : "N", s_v0 ? s_x0 : 16'd0, s_v0 ? s_y0 : 16'd0);
				wide[343:232] = xyline("Q", s_v1 ? (s_sq1 ? "S" : "C") : "N", s_v1 ? s_x1 : 16'd0, s_v1 ? s_y1 : 16'd0);
				wide[231:120] = xyline("Q", s_v2 ? (s_sq2 ? "S" : "C") : "N", s_v2 ? s_x2 : 16'd0, s_v2 ? s_y2 : 16'd0);
				for (k = 0; k < 42; k = k + 1)
					mb[k] <= wide[455 - 8 * k -: 8];
				mlen <= 7'd42;
				mi <= 7'd0;
				mbusy <= 1'b1;
			end else if (hb == 32'd0) begin
				banner <= 1'b1;
				banner_st <= stage;
			end else
				hb <= hb - 32'd1;
			// 换模式连发两笔 0x16。从语音切走时第一笔单片机应答了也不动，第二笔才归位。
			// 说一次模式就自己把第二笔补上。两笔之间空开，让第一笔先被单片机收完。
			if (home_pulse) begin
				home_pulse <= 1'b0;
				home_need <= 1'b1;
				home_wait <= 1'b0;
				home_busy <= 1'b0;
				home_second <= 1'b0;
				home_gap <= 2'd0;
				home_dly <= 30'd0;
			end else if (home_need && !home_wait) begin
				if (home_dly != 30'd0)
					home_dly <= home_dly - 30'd1;
				else if (home_to5 && bus_off && home_second)
					home_need <= 1'b0;
				else if (!man_req && i2c_idle) begin
					auto_req <= 1'b1;
					auto_echo <= 1'b1;
					auto_hex <= 1'b1;
					auto_stop <= 1'b0;
					auto_cmd <= 8'h16;
					auto_p0 <= 8'd0;
					auto_p1 <= 8'd0;
					auto_p2 <= 8'd0;
					auto_grp <= 8'd0;
					home_wait <= 1'b1;
					home_busy <= 1'b0;
					home_gap <= 2'd3;
					if (home_to5 && !home_second)
						off_dly <= 30'd595200000;
					else if (!home_to5) begin
						bus_off <= 1'b0;
						off_dly <= 30'd0;
					end
				end
			end else if (home_wait) begin
				if (!i2c_idle)
					home_busy <= 1'b1;
				else if (home_busy && i2c_done && !probe_busy) begin
					home_wait <= 1'b0;
					home_busy <= 1'b0;
					home_gap <= 2'd0;
					if (!home_second) begin
						home_second <= 1'b1;
						home_dly <= HOME_RETRY;
					end else
						home_need <= 1'b0;
				end else if (!home_busy && (home_gap != 2'd0))
					home_gap <= home_gap - 2'd1;
				else if (!home_busy)
					home_wait <= 1'b0;
			end
			if (cal_done) begin
				hpend <= 1'b1;
				hr <= cal_r;
				hg <= cal_g;
				hb <= cal_b;
			end
			if ((stage == 3'd4) && g_ready) begin
				gpend <= 1'b1;
				gk <= g_kind;
				gx <= g_cx;
				gy <= g_cy;
				ga <= g_area;
				if (g_kind == gseen) begin
					if (gcnt != 4'd8)
						gcnt <= gcnt + 4'd1;
				end else begin
					gseen <= g_kind;
					gcnt <= 4'd1;
					gphase <= 2'd0;
				end
			end
			if (stage != 3'd4) begin
				gcnt <= 4'd0;
				gseen <= "N";
				gsent <= 8'h00;
				gphase <= 2'd0;
			end else if ((gphase != 2'd0) && !((g_ready) && (g_kind != gseen)) && !home_hold && !bus_off && !man_req && i2c_idle) begin
				auto_req <= 1'b1;
				auto_cmd <= 8'h03;
				if (gphase == 2'd3) begin
					auto_p0 <= 8'd2;
					auto_p1 <= 8'hDC;
					auto_p2 <= 8'h05;
					gphase <= 2'd2;
				end else if (gphase == 2'd2) begin
					auto_p0 <= 8'd6;
					auto_p1 <= 8'hDC;
					auto_p2 <= 8'h05;
					gphase <= 2'd1;
				end else begin
					auto_p0 <= 8'd1;
					auto_p1 <= 8'h02;
					auto_p2 <= 8'h03;
					gphase <= 2'd0;
					gsent <= gseen;
				end
			end else if ((gcnt == 4'd8) && (gseen != gsent) && (gphase == 2'd0) && !home_hold && !bus_off && !man_req && i2c_idle) begin
				auto_req <= 1'b1;
				auto_p0 <= 8'd0;
				auto_p1 <= 8'd0;
				auto_p2 <= 8'd0;
				case (gseen)
					"N": begin
						auto_cmd <= 8'h0C;
						gphase <= 2'd3;
					end
					"L": begin
						auto_cmd <= 8'h03;
						auto_p0 <= 8'd6;
						auto_p1 <= 8'h08;
						auto_p2 <= 8'h07;
						gsent <= gseen;
					end
					"R": begin
						auto_cmd <= 8'h03;
						auto_p0 <= 8'd6;
						auto_p1 <= 8'hB0;
						auto_p2 <= 8'h04;
						gsent <= gseen;
					end
					"D": begin
						auto_cmd <= 8'h03;
						auto_p0 <= 8'd1;
						auto_p1 <= 8'hDC;
						auto_p2 <= 8'h05;
						gsent <= gseen;
					end
					"O": begin
						auto_cmd <= 8'h03;
						auto_p0 <= 8'd6;
						auto_p1 <= 8'hDC;
						auto_p2 <= 8'h05;
						gphase <= 2'd1;
					end
					default: begin
						auto_req <= 1'b0;
						gsent <= gseen;
					end
				endcase
			end
			// 颜色抓取先记下槽和颜色，等总线空了再发。连发两笔，中间空开约 100 ms。
			// 归位还占着总线时先不发，归位两笔走完再发，避免和 0x16 挤在同一拍。
			// 第二笔发出后才开始 10 秒。这之前来的一句先留着，两笔发完再读状态。
			if (grab_hold && voice_got && !voice_keep && !stat_busy && !voice_replay) begin
				keep_code <= voice_code;
				keep_tag <= voice_tag;
				voice_keep <= 1'b1;
			end
			if (voice_keep && grab_hold && !stat_busy && !grab_on && i2c_idle && !bus_off && !man_req) begin
				stat_pulse <= 1'b1;
				stat_busy <= 1'b1;
			end
			if (tmo_run && (grab_tmo != 32'd0))
				grab_tmo <= grab_tmo - 32'd1;
			if (tmo_run && (grab_tmo == 32'd1)) begin
				tmo_run <= 1'b0;
				grab_hold <= 1'b0;
				if (voice_keep)
					voice_replay <= 1'b1;
				voice_keep <= 1'b0;
				if (stat_busy && !i2c_done)
					stat_toss <= 1'b1;
				stat_busy <= 1'b0;
			end
			if (grab_on && (((stage != 3'd1) && (stage != 3'd2)) || bus_off)) begin
				grab_on <= 1'b0;
				if (grab_hold && !tmo_run) begin
					tmo_run <= 1'b1;
					grab_tmo <= GRAB_LOCK;
				end
			end else if (grab_on && !voice_got && !home_hold && !man_req && i2c_idle) begin
				if (grab_dly != 30'd0)
					grab_dly <= grab_dly - 30'd1;
				else begin
					auto_req <= 1'b1;
					auto_cmd <= 8'h15;
					auto_p0 <= grab_p0;
					auto_p1 <= grab_p1;
					auto_p2 <= 8'd0;
					if (!grab_shot) begin
						grab_shot <= 1'b1;
						grab_dly <= HOME_RETRY;
					end else begin
						grab_on <= 1'b0;
						tmo_run <= 1'b1;
						grab_tmo <= GRAB_LOCK;
					end
				end
			end
		end
	end
endmodule

// 先把距离算好并寄存，语音当拍只做选择。
module near_slot (
	input			clk,
	input			rst_n,
	input			ok,
	input [15:0]	x,
	input [15:0]	y,
	input			lv,
	input [15:0]	lx,
	input [15:0]	ly,
	input			mv,
	input [15:0]	mx,
	input [15:0]	my,
	input			rv,
	input [15:0]	rx,
	input [15:0]	ry,
	output reg [7:0] near
);
	reg ok1, lv1, mv1, rv1;
	reg [15:0] x1, y1, lx1, ly1, mx1, my1, rx1, ry1;
	reg ok2, lv2, mv2, rv2;
	reg [15:0] dlx, dly, dmx, dmy, drx, dry;
	reg ok3, lv3, mv3, rv3;
	reg [31:0] slx, sly, smx, smy, srx, sry;

	wire [31:0] dl = lv3 ? (slx + sly) : 32'hffffffff;
	wire [31:0] dm = mv3 ? (smx + smy) : 32'hffffffff;
	wire [31:0] dr = rv3 ? (srx + sry) : 32'hffffffff;

	always @(posedge clk) begin
		if (!rst_n) begin
			ok1 <= 1'b0; lv1 <= 1'b0; mv1 <= 1'b0; rv1 <= 1'b0;
			x1 <= 16'd0; y1 <= 16'd0;
			lx1 <= 16'd0; ly1 <= 16'd0; mx1 <= 16'd0; my1 <= 16'd0; rx1 <= 16'd0; ry1 <= 16'd0;
			ok2 <= 1'b0; lv2 <= 1'b0; mv2 <= 1'b0; rv2 <= 1'b0;
			dlx <= 16'd0; dly <= 16'd0; dmx <= 16'd0; dmy <= 16'd0; drx <= 16'd0; dry <= 16'd0;
			ok3 <= 1'b0; lv3 <= 1'b0; mv3 <= 1'b0; rv3 <= 1'b0;
			slx <= 32'd0; sly <= 32'd0; smx <= 32'd0; smy <= 32'd0; srx <= 32'd0; sry <= 32'd0;
			near <= "Z";
		end else begin
			ok1 <= ok; lv1 <= lv; mv1 <= mv; rv1 <= rv;
			x1 <= x; y1 <= y;
			lx1 <= lx; ly1 <= ly; mx1 <= mx; my1 <= my; rx1 <= rx; ry1 <= ry;
			ok2 <= ok1; lv2 <= lv1; mv2 <= mv1; rv2 <= rv1;
			dlx <= (x1 > lx1) ? (x1 - lx1) : (lx1 - x1);
			dly <= (y1 > ly1) ? (y1 - ly1) : (ly1 - y1);
			dmx <= (x1 > mx1) ? (x1 - mx1) : (mx1 - x1);
			dmy <= (y1 > my1) ? (y1 - my1) : (my1 - y1);
			drx <= (x1 > rx1) ? (x1 - rx1) : (rx1 - x1);
			dry <= (y1 > ry1) ? (y1 - ry1) : (ry1 - y1);
			ok3 <= ok2; lv3 <= lv2; mv3 <= mv2; rv3 <= rv2;
			slx <= dlx * dlx; sly <= dly * dly;
			smx <= dmx * dmx; smy <= dmy * dmy;
			srx <= drx * drx; sry <= dry * dry;
			if (!ok3)
				near <= "Z";
			else if (!lv3 && !mv3 && !rv3)
				near <= "U";
			else if ((dl <= dm) && (dl <= dr) && (dl < 32'd40000))
				near <= "L";
			else if ((dm <= dr) && (dm < 32'd40000))
				near <= "M";
			else if (dr < 32'd40000)
				near <= "R";
			else
				near <= "N";
		end
	end
endmodule
