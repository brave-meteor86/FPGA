// 按键和语音都转成手柄单舵机模式的同一条：功能号 0x14，舵机号，方向，步长。
// 方向 1 与手柄 MAX 相同，方向 0 与手柄 MIN 相同。
// D6 按键步长 50。语音步长 150。
// 上5+ 下5- 左6+ 右6- 张开1- 握拳1+ 方2+ 圆2- R1是3+ R2是3- L1是4+ L2是4-
// 回中是组 0。复位是功能号 12，对应手柄 Start。停止是功能号 7。
module arm_man (
	input			clk,
	input			rst_n,
	input			key_v,
	input [7:0]		key,
	input			voice_v,
	input [7:0]		voice_tag,
	input [7:0]		voice_code,
	output reg		req,
	output reg [7:0] cmd,
	output reg [7:0] p0,
	output reg [7:0] p1,
	output reg [7:0] p2,
	output reg		echo_v,
	output reg		echo_stop,
	output reg		echo_hex,
	output reg [7:0] echo_c0,
	output reg [7:0] echo_c1,
	output reg [7:0] echo_grp
);
	function [7:0] voice_op;
		input [7:0] tag;
		input [7:0] code;
		begin
			voice_op = 8'd0;
			if (tag == "V") begin
				case (code)
					8'h20: voice_op = "U";
					8'h21: voice_op = "D";
					8'h22: voice_op = "L";
					8'h23: voice_op = "R";
					8'h24: voice_op = "O";
					8'h25: voice_op = "C";
					8'h26: voice_op = "H";
					8'h27: voice_op = "G";
					8'h11: voice_op = "S";
					8'h60: voice_op = "W";
					8'h61: voice_op = "X";
					8'h62: voice_op = "Y";
					8'h63: voice_op = "E";
					8'h64: voice_op = "T";
					8'h65: voice_op = "V";
					8'h30: voice_op = 8'h83;
					8'h31: voice_op = 8'h85;
					8'h32: voice_op = 8'h84;
					8'h40: voice_op = 8'h95;
					8'h41: voice_op = 8'h96;
					8'h50: voice_op = "Z";
					default: voice_op = 8'd0;
				endcase
			end else if (tag == "S") begin
				case (code)
					8'h09: voice_op = "U";
					8'h0A: voice_op = "D";
					8'h0B: voice_op = "L";
					8'h0C: voice_op = "R";
					8'h0D: voice_op = "O";
					8'h0E: voice_op = "C";
					8'h0F: voice_op = "H";
					8'h10: voice_op = "G";
					8'h17: voice_op = "W";
					8'h18: voice_op = "X";
					8'h19: voice_op = "Y";
					8'h1A: voice_op = "E";
					8'h1B: voice_op = "T";
					8'h1C: voice_op = "V";
					8'h08: voice_op = "S";
					8'h11: voice_op = 8'h83;
					8'h12: voice_op = 8'h85;
					8'h13: voice_op = 8'h84;
					8'h14: voice_op = 8'h95;
					8'h15: voice_op = 8'h96;
					8'h16: voice_op = "Z";
					default: voice_op = 8'd0;
				endcase
			end
		end
	endfunction

	wire [7:0] vop = voice_op(voice_tag, voice_code);
	wire [7:0] op = key_v ? key : vop;
	wire fire = key_v || (voice_v && (vop != 8'd0));

	always @(posedge clk) begin
		if (!rst_n) begin
			req <= 1'b0;
			cmd <= 8'd0;
			p0 <= 8'd0;
			p1 <= 8'd0;
			p2 <= 8'd0;
			echo_v <= 1'b0;
			echo_stop <= 1'b0;
			echo_hex <= 1'b0;
			echo_c0 <= 8'd0;
			echo_c1 <= 8'd0;
			echo_grp <= 8'd0;
		end else begin
			req <= 1'b0;
			echo_v <= 1'b0;
			if (fire) begin
				req <= 1'b1;
				echo_v <= 1'b1;
				echo_stop <= 1'b0;
				echo_hex <= 1'b0;
				echo_c0 <= 8'd0;
				echo_c1 <= 8'd0;
				echo_grp <= 8'd0;
				cmd <= 8'h14;
				p0 <= 8'd0;
				p1 <= 8'd0;
				p2 <= key_v ? 8'd50 : 8'd150;
				case (op)
					"U": begin p0 <= 8'd5; p1 <= 8'd1; echo_c0 <= "U"; echo_c1 <= "+"; end
					"D": begin p0 <= 8'd5; p1 <= 8'd0; echo_c0 <= "D"; echo_c1 <= "-"; end
					"L": begin p0 <= 8'd6; p1 <= 8'd1; echo_c0 <= "L"; echo_c1 <= "+"; end
					"R": begin p0 <= 8'd6; p1 <= 8'd0; echo_c0 <= "R"; echo_c1 <= "-"; end
					"O": begin p0 <= 8'd1; p1 <= 8'd0; echo_c0 <= "O"; echo_c1 <= "-"; end
					"C": begin p0 <= 8'd1; p1 <= 8'd1; echo_c0 <= "C"; echo_c1 <= "+"; end
					"W": begin p0 <= 8'd2; p1 <= 8'd1; echo_c0 <= "W"; echo_c1 <= "+"; end
					"X": begin p0 <= 8'd2; p1 <= 8'd0; echo_c0 <= "X"; echo_c1 <= "-"; end
					"Y": begin p0 <= 8'd3; p1 <= 8'd1; echo_c0 <= "Y"; echo_c1 <= "+"; end
					"E": begin p0 <= 8'd3; p1 <= 8'd0; echo_c0 <= "E"; echo_c1 <= "-"; end
					"T": begin p0 <= 8'd4; p1 <= 8'd1; echo_c0 <= "T"; echo_c1 <= "+"; end
					"V": begin p0 <= 8'd4; p1 <= 8'd0; echo_c0 <= "V"; echo_c1 <= "-"; end
					"H": begin
						cmd <= 8'h06; p0 <= 8'd0; p1 <= 8'd1; p2 <= 8'd0;
						echo_hex <= 1'b1; echo_grp <= 8'd0;
					end
					"G": begin
						cmd <= 8'h06; p0 <= 8'd29; p1 <= 8'd1; p2 <= 8'd0;
						echo_hex <= 1'b1; echo_grp <= 8'd29;
					end
					"Z": begin cmd <= 8'h0C; p2 <= 8'd0; echo_c0 <= "Z"; echo_c1 <= "="; end
					"S": begin cmd <= 8'h07; p2 <= 8'd0; echo_stop <= 1'b1; end
					8'h83: begin
						cmd <= 8'h06; p0 <= 8'd3; p1 <= 8'd1; p2 <= 8'd0;
						echo_hex <= 1'b1; echo_grp <= 8'd3;
					end
					8'h85: begin
						cmd <= 8'h06; p0 <= 8'd5; p1 <= 8'd1; p2 <= 8'd0;
						echo_hex <= 1'b1; echo_grp <= 8'd5;
					end
					8'h84: begin
						cmd <= 8'h06; p0 <= 8'd4; p1 <= 8'd1; p2 <= 8'd0;
						echo_hex <= 1'b1; echo_grp <= 8'd4;
					end
					8'h95: begin
						cmd <= 8'h06; p0 <= 8'd21; p1 <= 8'd1; p2 <= 8'd0;
						echo_hex <= 1'b1; echo_grp <= 8'd21;
					end
					8'h96: begin
						cmd <= 8'h06; p0 <= 8'd22; p1 <= 8'd1; p2 <= 8'd0;
						echo_hex <= 1'b1; echo_grp <= 8'd22;
					end
					default: begin
						req <= 1'b0;
						echo_v <= 1'b0;
					end
				endcase
			end
		end
	end
endmodule
