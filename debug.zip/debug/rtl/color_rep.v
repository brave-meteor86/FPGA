// 红绿蓝各自一个中心。三种颜色互不占用同一个像素。面积不够的 valid 为 0。
module color_rep #(
	parameter ROI_X0 = 480,
	parameter ROI_Y0 = 300,
	parameter ROI_X1 = 1440,
	parameter ROI_Y1 = 780,
	parameter MIN_AREA = 80,
	parameter GAIN_R = 9'd310,
	parameter GAIN_G = 9'd256,
	parameter GAIN_B = 9'd490
)(
	input			clk,
	input			rst_n,
	input			vs,
	input			de,
	input signed [11:0] y_off,
	input [7:0]		r,
	input [7:0]		g,
	input [7:0]		b,
	input [7:0]		thr_r,
	input [7:0]		thr_g,
	input [7:0]		thr_b,
	input [7:0]		stab,
	input			auto_on,
	input [7:0]		rr,
	input [7:0]		rg,
	input [7:0]		rb,
	input [7:0]		gr,
	input [7:0]		gg,
	input [7:0]		gb,
	input [7:0]		brf,
	input [7:0]		bgf,
	input [7:0]		bbf,
	input [7:0]		kr,
	input [7:0]		kg,
	input [7:0]		kb,
	output reg		ready,
	output reg		vr,
	output reg		vg,
	output reg		vb,
	output reg [15:0] cx_r,
	output reg [15:0] cy_r,
	output reg [15:0] cx_g,
	output reg [15:0] cy_g,
	output reg [15:0] cx_b,
	output reg [15:0] cy_b,
	output reg [15:0] ar,
	output reg [15:0] ag,
	output reg [15:0] ab
);
	function [7:0] bal;
		input [7:0] pix;
		input [8:0] gain;
		reg [16:0] m;
		begin
			m = pix * gain;
			bal = (m[16:8] > 9'd255) ? 8'd255 : m[15:8];
		end
	endfunction

	wire [7:0] br = bal(r, GAIN_R);
	wire [7:0] bg = bal(g, GAIN_G);
	wire [7:0] bb = bal(b, GAIN_B);
	wire frame_done;
	wire [11:0] px, py;
	wire [19:0] area_r, area_g, area_b, area_o, area_h;
	wire [31:0] sumx_r, sumy_r, sumx_g, sumy_g, sumx_b, sumy_b, sumx_o, sumy_o, sumx_h, sumy_h;
	wire [11:0] minx_r, maxx_r, miny_r, maxy_r;
	wire [11:0] minx_g, maxx_g, miny_g, maxy_g;
	wire [11:0] minx_b, maxx_b, miny_b, maxy_b;
	wire [11:0] minx_o, maxx_o, miny_o, maxy_o;
	wire [11:0] minx_h, maxx_h, miny_h, maxy_h;

	vision_stat #(
		.ROI_X0(ROI_X0), .ROI_Y0(ROI_Y0), .ROI_X1(ROI_X1), .ROI_Y1(ROI_Y1),
		.MIN_AREA(MIN_AREA)
	) u_stat (
		.clk(clk), .rst_n(rst_n), .vs(vs), .de(de), .y_off(y_off), .r(br), .g(bg), .b(bb),
		.thr_r(thr_r), .thr_g(thr_g), .thr_b(thr_b), .stab(stab),
		.auto_on(auto_on),
		.rr(rr), .rg(rg), .rb(rb),
		.gr(gr), .gg(gg), .gb(gb),
		.br(brf), .bg(bgf), .bb(bbf),
		.kr(kr), .kg(kg), .kb(kb),
		.hand_mode(2'd0), .href_r(8'd0), .href_g(8'd0), .href_b(8'd0), .hand_tol(8'd0),
		.frame_done(frame_done), .x(px), .y(py),
		.area_r(area_r), .area_g(area_g), .area_b(area_b), .area_o(area_o), .area_h(area_h),
		.sumx_r(sumx_r), .sumy_r(sumy_r), .sumx_g(sumx_g), .sumy_g(sumy_g),
		.sumx_b(sumx_b), .sumy_b(sumy_b), .sumx_o(sumx_o), .sumy_o(sumy_o),
		.sumx_h(sumx_h), .sumy_h(sumy_h),
		.minx_r(minx_r), .maxx_r(maxx_r), .miny_r(miny_r), .maxy_r(maxy_r),
		.minx_g(minx_g), .maxx_g(maxx_g), .miny_g(miny_g), .maxy_g(maxy_g),
		.minx_b(minx_b), .maxx_b(maxx_b), .miny_b(miny_b), .maxy_b(maxy_b),
		.minx_o(minx_o), .maxx_o(maxx_o), .miny_o(miny_o), .maxy_o(maxy_o),
		.minx_h(minx_h), .maxx_h(maxx_h), .miny_h(miny_h), .maxy_h(maxy_h)
	);

	reg [2:0] st;
	reg div_start;
	reg [31:0] div_n;
	reg [19:0] div_d;
	wire [15:0] quot;
	wire div_done;
	reg [31:0] sx_r, sy_r, sx_g, sy_g, sx_b, sy_b;
	reg [19:0] a_r, a_g, a_b;
	reg [15:0] nx_r, ny_r, nx_g, ny_g, nx_b, ny_b;

	div_u32 u_div (
		.clk(clk), .rst_n(rst_n), .start(div_start),
		.dividend(div_n), .divisor(div_d), .quotient(quot), .done(div_done)
	);

	always @(posedge clk) begin
		if (!rst_n) begin
			st <= 3'd0;
			div_start <= 1'b0;
			div_n <= 32'd0;
			div_d <= 20'd0;
			sx_r <= 32'd0;
			sy_r <= 32'd0;
			sx_g <= 32'd0;
			sy_g <= 32'd0;
			sx_b <= 32'd0;
			sy_b <= 32'd0;
			a_r <= 20'd0;
			a_g <= 20'd0;
			a_b <= 20'd0;
			nx_r <= 16'd0;
			ny_r <= 16'd0;
			nx_g <= 16'd0;
			ny_g <= 16'd0;
			nx_b <= 16'd0;
			ny_b <= 16'd0;
			ready <= 1'b0;
			vr <= 1'b0;
			vg <= 1'b0;
			vb <= 1'b0;
			cx_r <= 16'd0;
			cy_r <= 16'd0;
			cx_g <= 16'd0;
			cy_g <= 16'd0;
			cx_b <= 16'd0;
			cy_b <= 16'd0;
			ar <= 16'd0;
			ag <= 16'd0;
			ab <= 16'd0;
		end else begin
			div_start <= 1'b0;
			ready <= 1'b0;
			case (st)
				3'd0: begin
					if (frame_done) begin
						a_r <= area_r;
						a_g <= area_g;
						a_b <= area_b;
						sx_r <= sumx_r;
						sy_r <= sumy_r;
						sx_g <= sumx_g;
						sy_g <= sumy_g;
						sx_b <= sumx_b;
						sy_b <= sumy_b;
						nx_r <= 16'd0;
						ny_r <= 16'd0;
						nx_g <= 16'd0;
						ny_g <= 16'd0;
						nx_b <= 16'd0;
						ny_b <= 16'd0;
						if (area_r >= MIN_AREA) begin
							div_n <= sumx_r;
							div_d <= area_r;
							div_start <= 1'b1;
							st <= 3'd1;
						end else if (area_g >= MIN_AREA) begin
							div_n <= sumx_g;
							div_d <= area_g;
							div_start <= 1'b1;
							st <= 3'd3;
						end else if (area_b >= MIN_AREA) begin
							div_n <= sumx_b;
							div_d <= area_b;
							div_start <= 1'b1;
							st <= 3'd5;
						end else begin
							vr <= 1'b0;
							vg <= 1'b0;
							vb <= 1'b0;
							cx_r <= 16'd0;
							cy_r <= 16'd0;
							cx_g <= 16'd0;
							cy_g <= 16'd0;
							cx_b <= 16'd0;
							cy_b <= 16'd0;
							ar <= 16'd0;
							ag <= 16'd0;
							ab <= 16'd0;
							ready <= 1'b1;
						end
					end
				end
				3'd1: if (div_done) begin
					nx_r <= quot;
					div_n <= sy_r;
					div_d <= a_r;
					div_start <= 1'b1;
					st <= 3'd2;
				end
				3'd2: if (div_done) begin
					ny_r <= quot;
					if (a_g >= MIN_AREA) begin
						div_n <= sx_g;
						div_d <= a_g;
						div_start <= 1'b1;
						st <= 3'd3;
					end else if (a_b >= MIN_AREA) begin
						div_n <= sx_b;
						div_d <= a_b;
						div_start <= 1'b1;
						st <= 3'd5;
					end else begin
						vr <= 1'b1;
						vg <= 1'b0;
						vb <= 1'b0;
						cx_r <= nx_r;
						cy_r <= quot;
						cx_g <= 16'd0;
						cy_g <= 16'd0;
						cx_b <= 16'd0;
						cy_b <= 16'd0;
						ar <= a_r[15:0];
						ag <= 16'd0;
						ab <= 16'd0;
						ready <= 1'b1;
						st <= 3'd0;
					end
				end
				3'd3: if (div_done) begin
					nx_g <= quot;
					div_n <= sy_g;
					div_d <= a_g;
					div_start <= 1'b1;
					st <= 3'd4;
				end
				3'd4: if (div_done) begin
					ny_g <= quot;
					if (a_b >= MIN_AREA) begin
						div_n <= sx_b;
						div_d <= a_b;
						div_start <= 1'b1;
						st <= 3'd5;
					end else begin
						vr <= (a_r >= MIN_AREA);
						vg <= 1'b1;
						vb <= 1'b0;
						cx_r <= nx_r;
						cy_r <= ny_r;
						cx_g <= nx_g;
						cy_g <= quot;
						cx_b <= 16'd0;
						cy_b <= 16'd0;
						ar <= a_r[15:0];
						ag <= a_g[15:0];
						ab <= 16'd0;
						ready <= 1'b1;
						st <= 3'd0;
					end
				end
				3'd5: if (div_done) begin
					nx_b <= quot;
					div_n <= sy_b;
					div_d <= a_b;
					div_start <= 1'b1;
					st <= 3'd6;
				end
				default: if (div_done) begin
					ny_b <= quot;
					vr <= (a_r >= MIN_AREA);
					vg <= (a_g >= MIN_AREA);
					vb <= (a_b >= MIN_AREA);
					cx_r <= nx_r;
					cy_r <= ny_r;
					cx_g <= nx_g;
					cy_g <= ny_g;
					cx_b <= nx_b;
					cy_b <= quot;
					ar <= a_r[15:0];
					ag <= a_g[15:0];
					ab <= a_b[15:0];
					ready <= 1'b1;
					st <= 3'd0;
				end
			endcase
		end
	end
endmodule
